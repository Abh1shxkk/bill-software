@extends('layouts.admin')

@section('title', 'Claim to Supplier Transaction')

@push('styles')
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    input:focus { box-shadow: none !important; }
    .cts .header-section { background: white; border: 1px solid #dee2e6; padding: 10px; margin-bottom: 8px; border-radius: 4px; }
    .cts .header-row { display: flex; align-items: center; gap: 15px; margin-bottom: 6px; }
    .cts .field-group { display: flex; align-items: center; gap: 6px; }
    .cts .inner-card { background: #e8f4f8; border: 1px solid #b8d4e0; padding: 8px; border-radius: 3px; }
    .cts .readonly-field { background-color: #e9ecef !important; cursor: not-allowed; }
    .table-compact { font-size: 10px; margin-bottom: 0; }
    .table-compact th, .table-compact td { padding: 4px; vertical-align: middle; height: 45px; }
    .table-compact th { background: #e9ecef; font-weight: 600; text-align: center; border: 1px solid #dee2e6; height: 40px; }
    .table-compact input { font-size: 10px; padding: 2px 4px; height: 22px; border: 1px solid #ced4da; width: 100%; }
    
    /* Modal Styles */
    .modal-backdrop-custom {
        display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.5); z-index: 99998; opacity: 0; transition: opacity 0.3s ease;
    }
    .modal-backdrop-custom.show { display: block; opacity: 1; }
    .item-modal {
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.7);
        width: 90%; max-width: 800px; max-height: 90vh; background: white; border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); z-index: 99999; opacity: 0; transition: all 0.3s ease;
    }
    .item-modal.show { display: block; opacity: 1; transform: translate(-50%, -50%) scale(1); }
    .item-modal-header {
        padding: 15px 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;
        border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center;
    }
    .item-modal-header h5 { margin: 0; font-size: 16px; }
    .btn-close-custom { background: none; border: none; color: white; font-size: 24px; cursor: pointer; line-height: 1; }
    .item-modal-body { padding: 15px 20px; max-height: 60vh; overflow-y: auto; }
    .item-modal-footer { padding: 10px 20px; border-top: 1px solid #dee2e6; text-align: right; }
    
    /* Additional Details Modal */
    .additional-modal {
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.7);
        width: 450px; max-height: 90vh; background: #f0f0f0; border: 2px solid #999;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); z-index: 99999; opacity: 0; transition: all 0.3s ease;
    }
    .additional-modal.show { display: block; opacity: 1; transform: translate(-50%, -50%) scale(1); }
    .additional-modal-body { padding: 15px 20px; }
    .additional-modal .field-row { display: flex; align-items: center; margin-bottom: 10px; }
    .additional-modal .field-row label { width: 180px; font-weight: 500; }
    .additional-modal .field-row input, .additional-modal .field-row select { border: 1px solid #999; padding: 3px 6px; font-size: 12px; }
    .additional-modal .field-row input[type="text"].small-input { width: 40px; text-align: center; }
    .additional-modal .field-row input[type="date"] { width: 120px; }
    .additional-modal .ok-btn { background: #e0e0e0; border: 2px outset #ccc; padding: 3px 20px; cursor: pointer; font-weight: 500; }
    .additional-modal .ok-btn:hover { background: #d0d0d0; }
    
    /* Rate Modal Styles */
    .rate-modal {
        display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.7);
        width: 420px; background: #fff; border-radius: 6px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.3); z-index: 99999; opacity: 0; transition: all 0.25s ease;
    }
    .rate-modal.show { display: block; opacity: 1; transform: translate(-50%, -50%) scale(1); }
    .rate-modal-header {
        background: #dc3545; color: white; padding: 10px 16px;
        border-radius: 6px 6px 0 0; font-weight: 600; font-size: 13px;
        display: flex; justify-content: space-between; align-items: center;
    }
    .rate-modal-body { padding: 18px 20px 14px; background: #fff8f8; border-radius: 0 0 6px 6px; }
    .rate-modal .field-row { display: flex; align-items: center; margin-bottom: 12px; gap: 12px; flex-wrap: wrap; }
    .rate-modal .field-row label { font-weight: 600; font-size: 12px; white-space: nowrap; min-width: 100px; }
    .rate-modal .field-row input { border: 1px solid #aaa; padding: 5px 8px; font-size: 12px; width: 110px; border-radius: 3px; }
    .rate-modal .field-row input.yellow-bg { background: #ffff99; }
    .rate-modal .rate-ok-btn {
        background: #0d6efd; color: white; border: none; padding: 5px 24px;
        font-size: 12px; font-weight: 600; border-radius: 3px; cursor: pointer;
    }
    .rate-modal .rate-ok-btn:hover { background: #0b5ed7; }
    
    /* Row Selection Highlight */
    .table-compact tbody tr { cursor: pointer; transition: all 0.2s ease; }
    .table-compact tbody tr:hover { background: #e3f2fd; }
    .table-compact tbody tr.selected-row { background: #bbdefb !important; border: 2px solid #1976d2 !important; }
    .table-compact tbody tr.selected-row td { border-color: #1976d2; }

@media (max-width: 767px) {
    /* ── Page title row ── */
    .cts .d-flex.justify-content-between.align-items-center.mb-3 {
        flex-wrap: wrap !important;
    }
    .cts .d-flex.justify-content-between.align-items-center.mb-3 > div {
        width: 100% !important;
        margin-bottom: 6px !important;
    }

    /* ── Header left-col (style="width:200px") ── */
    #trn-left-col {
        width: 100% !important;
        flex: 0 0 100% !important;
    }

    /* ── d-flex gap-3 mb-2 (header outer row) ── */
    .cts .header-section .d-flex.gap-3.mb-2 {
        flex-wrap: wrap !important;
    }

    /* ── inner-card cols ── */
    .cts .inner-card .col-md-4,
    .cts .inner-card .col-md-5,
    .cts .inner-card .col-md-3 {
        flex: 0 0 100% !important;
        max-width: 100% !important;
    }

    /* ── field-group inputs ── */
    .cts .field-group {
        flex-wrap: wrap !important;
    }
    .cts .field-group input,
    .cts .field-group select {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── supplierWrapper ── */
    #supplierWrapper {
        width: 100% !important;
        flex: 1 !important;
    }

    /* ── Items table ── */
    #itemsTableContainer {
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch !important;
    }
    #itemsTableContainer .table-compact {
        min-width: 820px !important;
    }

    /* ── Calculation section ── */
    .bg-white.border.rounded.p-2.mb-2 .d-flex.flex-wrap input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── Invoice info section (pink #f8c0f8) ── */
    .border.rounded.p-2.mb-2[style*="background: #f8c0f8"] .d-flex {
        flex-wrap: wrap !important;
    }
    .border.rounded.p-2.mb-2[style*="background: #f8c0f8"] input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── Totals row section (pink #f8c0c0) ── */
    .border.rounded.p-2.mb-2[style*="background: #f8c0c0"] .d-flex {
        flex-wrap: wrap !important;
        justify-content: flex-start !important;
    }
    .border.rounded.p-2.mb-2[style*="background: #f8c0c0"] input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── Summary section (grey #d4d4d4) ── */
    .border.rounded.p-2.mb-2[style*="background: #d4d4d4"] .d-flex {
        flex-wrap: wrap !important;
        justify-content: flex-start !important;
    }
    .border.rounded.p-2.mb-2[style*="background: #d4d4d4"] input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── Action buttons ── */
    .d-flex.justify-content-between.mt-3 {
        flex-wrap: wrap !important;
    }
    .d-flex.justify-content-between.mt-3 > div {
        width: 100% !important;
        flex-wrap: wrap !important;
        display: flex !important;
    }
    .d-flex.justify-content-between.mt-3 > div .btn,
    .d-flex.justify-content-between.mt-3 > .btn {
        flex: 1 !important;
        margin: 2px !important;
    }
}
</style>
@endpush

@section('content')
<section class="cts py-5">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h4 class="mb-0 d-flex align-items-center"><i class="bi bi-file-earmark-text me-2"></i> Claim to Supplier Transaction</h4>
                <div class="text-muted small">Create new claim to supplier transaction</div>
            </div>
        </div>

        <div class="card shadow-sm border-0 rounded">
            <div class="card-body">
                <form id="ctsForm" method="POST" autocomplete="off">
                    <!-- Header Section -->
                    <div class="header-section">
                        <div class="d-flex gap-3 mb-2">
                            <div id="trn-left-col" style="width: 200px;">
                                <div class="field-group mb-2">
                                    <label style="width: 50px;">Date:</label>
                                    <input type="date" id="claim_date" name="claim_date" class="form-control" style="width: 140px;" value="{{ date('Y-m-d') }}" required>
                                </div>
                                <div class="field-group mb-2">
                                    <label style="width: 50px;">Day:</label>
                                    <input type="text" id="day_name" class="form-control readonly-field" style="width: 140px;" value="{{ date('l') }}" readonly>
                                </div>
                                <div class="field-group mb-2">
                                    <label style="width: 50px;">T. No.:</label>
                                    <input type="text" id="trn_no" name="trn_no" class="form-control readonly-field" style="width: 140px;" readonly>
                                </div>
                            </div>

                            <div class="inner-card flex-grow-1 overflow-hidden">
                                <div class="row g-2">
                                    <div class="col-md-4">
                                        <div class="field-group">
                                            <label style="width: 100px;">Supplier :</label>
                                            <input type="hidden" id="supplier_id" name="supplier_id">
                                            <div style="position:relative; flex:1;" id="supplierWrapper">
                                                <input type="text" id="supplier_search" class="form-control no-select2"
                                                       placeholder="Search supplier..."
                                                       autocomplete="off"
                                                       oninput="_filterSupplierList()"
                                                       onclick="_openSupplierDrop()"
                                                       style="font-size:12px;">
                                                <div id="supplierDropList"
                                                     style="display:none; position:absolute; z-index:99999; top:100%; left:0;
                                                            width:250px; max-height:220px; overflow-y:auto;
                                                            background:white; border:1px solid #ccc;
                                                            box-shadow:0 4px 8px rgba(0,0,0,.15);">
                                                    @foreach($suppliers as $supplier)
                                                    <div class="supplier-drop-item"
                                                         data-value="{{ $supplier->supplier_id }}"
                                                         data-name="{{ $supplier->name }}"
                                                         style="padding:5px 10px; cursor:pointer; font-size:12px;"
                                                         onmousedown="_selectSupplierItem(this)">{{ $supplier->name }}</div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="field-group">
                                            <label style="width: 80px;">Claim Date:</label>
                                            <input type="date" class="form-control" id="invoice_date" name="invoice_date">
                                        </div>
                                    </div>
                                </div>
                                <div class="row g-2 mt-1">
                                    <div class="col-md-4">
                                        <div class="field-group">
                                            <label style="width: 100px;">Tax [Y/N]:</label>
                                            <input type="text" class="form-control" id="tax_flag" name="tax_flag" value="Y" maxlength="1" style="width: 50px;">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="field-group">
                                            <label style="width: 80px;">Narration:</label>
                                            <input type="text" class="form-control" id="narration" name="narration">
                                        </div>
                                    </div>
                                    <div class="col-md-3 text-end">
                                        <button type="button" class="btn btn-info btn-sm" onclick="showAdditionalDetailsModal()">
                                            <i class="bi bi-gear me-1"></i> Additional Details
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Items Table -->
                    <div class="bg-white border rounded p-2 mb-2">
                        <div class="table-responsive" style="overflow-y: auto; max-height: 310px;" id="itemsTableContainer">
                            <table class="table table-bordered table-compact">
                                <thead style="position: sticky; top: 0; background: #9999cc; color: #000; z-index: 10;">
                                    <tr>
                                        <th style="width: 80px;">Item Code</th>
                                        <th style="width: 200px;">Item Name</th>
                                        <th style="width: 80px;">Batch</th>
                                        <th style="width: 60px;">Exp.</th>
                                        <th style="width: 60px;">Qty.</th>
                                        <th style="width: 60px;">F.Qty</th>
                                        <th style="width: 80px;">Rate</th>
                                        <th style="width: 60px;">Dis.%</th>
                                        <th style="width: 90px;">Amount</th>
                                        <th style="width: 50px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="itemsTableBody"></tbody>
                            </table>
                        </div>
                        <div class="text-center mt-2">
                            <button type="button" class="btn btn-sm btn-primary" onclick="showAddItemModal()">
                                <i class="bi bi-plus-circle me-1"></i> Add Item
                            </button>
                        </div>
                    </div>

                    <!-- Calculation Section -->
                    <div class="bg-white border rounded p-2 mb-2" style="overflow: hidden;">
                        <div class="d-flex flex-wrap align-items-center gap-3" style="font-size: 11px;">
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>HSN</strong></label>
                                <input type="text" class="form-control readonly-field text-center" id="calc_hsn_code" readonly style="width: 80px; height: 26px; font-size: 11px;" value="">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>SC%</strong></label>
                                <input type="number" class="form-control readonly-field text-center" id="calc_sc_percent" readonly style="width: 60px; height: 26px; font-size: 11px;" value="0.000">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>TAX%</strong></label>
                                <input type="number" class="form-control readonly-field text-center" id="calc_tax_percent" readonly style="width: 60px; height: 26px; font-size: 11px;" value="0.000">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>CGST(%)</strong></label>
                                <input type="text" class="form-control readonly-field text-center" id="calc_cgst_percent" readonly style="width: 45px; height: 26px; font-size: 11px;" value="0">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>CGST Amt</strong></label>
                                <input type="number" class="form-control readonly-field text-center" id="calc_cgst_amount" readonly style="width: 70px; height: 26px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>SGST(%)</strong></label>
                                <input type="text" class="form-control readonly-field text-center" id="calc_sgst_percent" readonly style="width: 45px; height: 26px; font-size: 11px;" value="0">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>SGST Amt</strong></label>
                                <input type="number" class="form-control readonly-field text-center" id="calc_sgst_amount" readonly style="width: 70px; height: 26px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>W.S.RATE</strong></label>
                                <input type="number" class="form-control readonly-field text-center" id="calc_ws_rate" readonly style="width: 65px; height: 26px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0"><strong>S.RATE</strong></label>
                                <input type="number" class="form-control readonly-field text-center" id="calc_s_rate" readonly style="width: 65px; height: 26px; font-size: 11px;" value="0.00">
                            </div>
                        </div>
                    </div>

                    <!-- Invoice Info Section (Pink Background) -->
                    <div class="border rounded p-2 mb-2" style="background: #f8c0f8; overflow: hidden;">
                        <div class="d-flex align-items-center gap-3" style="font-size: 11px;">
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0" style="font-weight: bold;">Inv.No :</label>
                                <input type="text" class="form-control form-control-sm" id="ref_inv_no" name="ref_inv_no" style="width: 80px; height: 26px; font-size: 11px;" value="/0">
                            </div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="mb-0" style="font-weight: bold;">Inv.Date :</label>
                                <input type="date" class="form-control form-control-sm" id="ref_inv_date" name="ref_inv_date" style="width: 120px; height: 26px; font-size: 11px;" value="{{ date('Y-m-d') }}">
                            </div>
                            <div class="d-flex align-items-center gap-1 flex-grow-1">
                                <label class="mb-0" style="font-weight: bold;">Customer :</label>
                                <input type="text" class="form-control form-control-sm" id="ref_customer_code" name="ref_customer_code" style="width: 80px; height: 26px; font-size: 11px;" placeholder="Code">
                                <input type="text" class="form-control form-control-sm flex-grow-1" id="ref_customer_name" name="ref_customer_name" style="height: 26px; font-size: 11px;" readonly placeholder="Customer Name">
                            </div>
                        </div>
                    </div>

                    <!-- Totals Row Section (Pink Background) -->
                    <div class="border rounded p-2 mb-2" style="background: #f8c0c0; overflow: hidden;">
                        <div class="d-flex align-items-center justify-content-between" style="font-size: 11px;">
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">N.T AMT</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="total_nt_amt" readonly style="width: 90px; height: 26px; font-size: 11px; background: #fff;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">SC</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="total_sc" readonly style="width: 80px; height: 26px; font-size: 11px; background: #fff;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">DIS. AMT</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="total_dis_amt" readonly style="width: 90px; height: 26px; font-size: 11px; background: #fff;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">SCM. AMT</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="total_scm_amt" readonly style="width: 90px; height: 26px; font-size: 11px; background: #fff;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Tax</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="total_tax" readonly style="width: 80px; height: 26px; font-size: 11px; background: #fff;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">INV. AMT</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="total_inv_amt" readonly style="width: 90px; height: 26px; font-size: 11px; background: #fff;" value="0.00">
                            </div>
                        </div>
                    </div>

                    <!-- Summary Section -->
                    <div class="border rounded p-2 mb-2" style="background: #d4d4d4;">
                        <!-- Row 1: Packing, N.T Amt, Scm. Amt, Comp, Srlno -->
                        <div class="d-flex align-items-center" style="font-size: 11px; gap: 15px;">
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold; width: 50px;">Packing</label>
                                <input type="text" class="form-control form-control-sm readonly-field" id="packing" readonly style="width: 60px; height: 24px; font-size: 11px;">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">N.T Amt.</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" name="nt_amount" id="ntAmount" readonly style="width: 80px; height: 24px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Scm. Amt.</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" name="scm_amount" id="scmAmount" readonly style="width: 80px; height: 24px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Comp :</label>
                                <input type="text" class="form-control form-control-sm readonly-field" id="companyName" readonly style="width: 100px; height: 24px; font-size: 11px;">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Srlno.</label>
                                <input type="text" class="form-control form-control-sm readonly-field text-center" id="srlNo" readonly style="width: 40px; height: 24px; font-size: 11px;">
                            </div>
                        </div>
                        <!-- Row 2: Unit, SC Amt, Net Amt, Lctn, SCM -->
                        <div class="d-flex align-items-center mt-1" style="font-size: 11px; gap: 15px;">
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold; width: 50px;">Unit</label>
                                <input type="text" class="form-control form-control-sm readonly-field" id="unit" readonly style="width: 60px; height: 24px; font-size: 11px;">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">SC Amt.</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" name="sc_amount" id="scAmount" readonly style="width: 80px; height: 24px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Net Amt.</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" name="inv_amount" id="invAmount" readonly style="width: 80px; height: 24px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Lctn :</label>
                                <input type="text" class="form-control form-control-sm readonly-field" id="locationField" readonly style="width: 60px; height: 24px; font-size: 11px;">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">SCM.</label>
                                <input type="text" class="form-control form-control-sm readonly-field text-center" id="scmField" readonly style="width: 40px; height: 24px; font-size: 11px;" value="0">
                                <span>+</span>
                                <input type="text" class="form-control form-control-sm readonly-field text-center" id="scmField2" readonly style="width: 40px; height: 24px; font-size: 11px;" value="0">
                            </div>
                        </div>
                        <!-- Row 3: Cl. Qty, DIS. Amt, Tax Amt -->
                        <div class="d-flex align-items-center mt-1" style="font-size: 11px; gap: 15px;">
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold; width: 50px;">Cl. Qty</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" id="clQty" readonly style="width: 60px; height: 24px; font-size: 11px;" value="0">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">DIS. Amt.</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" name="dis_amount" id="disAmount" readonly style="width: 80px; height: 24px; font-size: 11px;" value="0.00">
                            </div>
                            <div class="d-flex align-items-center" style="gap: 5px;">
                                <label class="mb-0" style="font-weight: bold;">Tax Amt.</label>
                                <input type="number" class="form-control form-control-sm readonly-field text-end" name="tax_amount" id="taxAmount" readonly style="width: 80px; height: 24px; font-size: 11px;" value="0.00">
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex justify-content-between mt-3">
                        <div>
                            <button type="button" class="btn btn-success" id="saveBtn">Save (End)</button>
                            <button type="button" class="btn btn-danger" id="deleteItemBtn">Delete Item</button>
                        </div>
                        <button type="button" class="btn btn-secondary" onclick="window.location.reload()">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Item and Batch Selection Modal Components -->
@include('components.modals.item-selection', [
    'id' => 'claimToSupplierItemModal',
    'module' => 'claim-to-supplier',
    'showStock' => true,
    'rateType' => 'pur_rate',
    'showCompany' => true,
    'showHsn' => false,
    'batchModalId' => 'claimToSupplierBatchModal',
])

@include('components.modals.batch-selection', [
    'id' => 'claimToSupplierBatchModal',
    'module' => 'claim-to-supplier',
    'showOnlyAvailable' => true,
    'rateType' => 'pur_rate',
    'showCostDetails' => true,
])

@endsection

@push('scripts')
<script>
let rowIndex = 0;
let allItems = [];
let selectedItem = null;
let currentRowForRate = null; // Track which row needs rate modal

// Additional Details Modal Data
let additionalDetails = {
    blank_statement: 'Y',
    rate_type: 'R',
    from_date: '{{ date("Y-m-d") }}',
    to_date: '{{ date("Y-m-d") }}',
    company_code: '',
    company_name: '',
    division: '00'
};

// ============================================================================
// BRIDGE FUNCTIONS FOR REUSABLE MODAL COMPONENTS
// ============================================================================

/**
 * Bridge function called by reusable modal components after item and batch selection
 */
function onItemBatchSelectedFromModal(itemData, batchData) {
    console.log('🎯 Claim to Supplier: onItemBatchSelectedFromModal called', {itemData, batchData});
    
    if (!itemData || !itemData.id) {
        console.error('❌ Claim to Supplier: Invalid item data received');
        return;
    }
    
    // Create new row
    const tbody = document.getElementById('itemsTableBody');
    const newRowIndex = rowIndex++;
    
    const row = document.createElement('tr');
    row.id = `row-${newRowIndex}`;
    // data-row attribute — used by jQuery keyboard handler ($row.data('row'))
    row.setAttribute('data-row', newRowIndex);
    row.dataset.itemId = itemData.id;
    row.dataset.batchId = batchData?.id || '';
    row.onclick = function() { selectRow(newRowIndex); };
    
    // Get rates and calculate
    const rate = batchData?.pur_rate || batchData?.cost || batchData?.avg_pur_rate || itemData.pur_rate || itemData.p_rate || 0;
    const qty = 1;
    const amount = (qty * rate).toFixed(2);
    
    // ⚠️ Class names MUST match keyboard handler: .item-code .item-name .batch-no .expiry .qty .free-qty .rate .dis-percent .amount
    row.innerHTML = `
        <td><input type="text" class="form-control item-code" value="${itemData.id || ''}" readonly tabindex="-1"></td>
        <td><input type="text" class="form-control item-name" value="${itemData.name || ''}" readonly tabindex="-1"></td>
        <td><input type="text" class="form-control batch-no" value="${batchData?.batch_no || ''}" readonly tabindex="-1"></td>
        <td><input type="text" class="form-control expiry" value="${batchData?.expiry_display || batchData?.expiry || ''}" readonly tabindex="-1"></td>
        <td><input type="number" class="form-control qty" data-row="${newRowIndex}" value="${qty}" step="0.01" min="0"></td>
        <td><input type="number" class="form-control free-qty" data-row="${newRowIndex}" value="0" min="0"></td>
        <td><input type="number" class="form-control rate" data-row="${newRowIndex}" value="${rate}" step="0.01"></td>
        <td><input type="number" class="form-control dis-percent" data-row="${newRowIndex}" value="0" step="0.01"></td>
        <td><input type="number" class="form-control amount readonly-field" value="${amount}" step="0.01" readonly tabindex="-1"></td>
        <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(${newRowIndex})" tabindex="-1"><i class="bi bi-x"></i></button></td>
        <input type="hidden" name="items[${newRowIndex}][item_id]" value="${itemData.id || ''}">
        <input type="hidden" name="items[${newRowIndex}][batch_id]" value="${batchData?.id || ''}">
        <input type="hidden" name="items[${newRowIndex}][hsn_code]" value="${itemData.hsn_code || ''}">
        <input type="hidden" name="items[${newRowIndex}][packing]" value="${itemData.packing || ''}">
        <input type="hidden" name="items[${newRowIndex}][unit]" value="${itemData.unit || '1'}">
        <input type="hidden" name="items[${newRowIndex}][company_name]" value="${itemData.company_name || ''}">
        <input type="hidden" name="items[${newRowIndex}][mrp]" value="${itemData.mrp || 0}">
        <input type="hidden" name="items[${newRowIndex}][s_rate]" value="${itemData.s_rate || 0}">
        <input type="hidden" name="items[${newRowIndex}][pur_rate]" value="${rate}">
    `;
    
    tbody.appendChild(row);
    
    // Store item data on jQuery row for calc functions
    const $row = $(`tr[data-row="${newRowIndex}"]`);
    $row.data('item_id', itemData.id);
    $row.data('rate_charged', 0);
    $row.data('actual_rate', 0);
    const itemDataObj = {
        s_rate:       parseFloat(itemData.s_rate)       || 0,
        ws_rate:      parseFloat(itemData.ws_rate)      || 0,
        hsn_code:     itemData.hsn_code                 || '',
        cgst_percent: parseFloat(itemData.cgst_percent) || 0,
        sgst_percent: parseFloat(itemData.sgst_percent) || 0,
        sc_percent:   parseFloat(itemData.sc_percent)   || 0,
        scm_percent:  parseFloat(itemData.scm_percent)  || 0,
        packing:      itemData.packing                  || '',
        unit:         itemData.unit                     || '',
        company_name: itemData.company_name             || '',
        location:     itemData.location                 || ''
    };
    $row.data('item_data', itemDataObj);
    
    // Select row highlight
    $('#itemsTableBody tr').removeClass('selected-row');
    $row.addClass('selected-row');
    updateSelectedRowDetails($row);
    
    if (typeof calculateTotals === 'function') calculateTotals();
    
    console.log('✅ Claim to Supplier: Row created successfully', newRowIndex);
    
    // Batch + Expiry already filled by batch modal → focus qty directly
    setTimeout(() => {
        const qtyField = row.querySelector('.qty');
        if (qtyField) { qtyField.focus(); qtyField.select(); }
    }, 100);
}

/**
 * Bridge function to open item selection modal
 */
function showAddItemModal() {
    console.log('🎯 Claim to Supplier: showAddItemModal called');
    
    // Check if modal component function exists
    if (typeof window.openItemModal_claimToSupplierItemModal === 'function') {
        console.log('✅ Claim to Supplier: Opening reusable item modal');
        window.openItemModal_claimToSupplierItemModal();
    } else {
        console.error('❌ Claim to Supplier: openItemModal_claimToSupplierItemModal function not found. Modal component may not be loaded.');
        alert('Error: Item selection modal not available. Please refresh the page.');
    }
}

// ============================================================================
// EXISTING FUNCTIONS
// ============================================================================

$(document).ready(function() {
    loadNextTransactionNumber();
    
    $('#claim_date').on('change', function() {
        const date = new Date($(this).val());
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $('#day_name').val(days[date.getDay()]);
    });
    
    // Customer code lookup
    $('#ref_customer_code').on('change', function() {
        const code = $(this).val();
        if (code) {
            $.get("{{ url('admin/customers') }}/" + code, function(response) {
                if (response && response.name) {
                    $('#ref_customer_name').val(response.name);
                } else {
                    $('#ref_customer_name').val('');
                }
            }).fail(function() { 
                $('#ref_customer_name').val(''); 
            });
        } else {
            $('#ref_customer_name').val('');
        }
    });
    
    $('#saveBtn').on('click', saveTransaction);
});

function loadNextTransactionNumber() {
    $.get("{{ route('admin.claim-to-supplier.next-trn-no') }}", function(response) {
        $('#trn_no').val(response.next_trn_no);
    });
}

// ==================== ADDITIONAL DETAILS MODAL ====================
function showAdditionalDetailsModal() {
    const isBlankY = additionalDetails.blank_statement === 'Y';
    const disabledAttr = isBlankY ? 'disabled' : '';
    const disabledStyle = isBlankY ? 'background: #ccc; cursor: not-allowed;' : '';
    
    const modalHTML = `
        <div class="modal-backdrop-custom" id="additionalModalBackdrop" onclick="closeAdditionalDetailsModal()"></div>
        <div class="additional-modal" id="additionalModal">
            <div class="additional-modal-body">
                <div class="field-row">
                    <label>Blank statement [ Y/N ] :</label>
                    <input type="text" id="add_blank_statement" class="small-input" value="${additionalDetails.blank_statement}" maxlength="1" style="background: #ffff00;" onkeyup="toggleAdditionalFields()">
                </div>
                <div class="field-row">
                    <label>From P / S / R :</label>
                    <input type="text" id="add_rate_type" class="small-input additional-field" value="${additionalDetails.rate_type}" maxlength="1" ${disabledAttr} style="${disabledStyle}">
                </div>
                <div class="field-row">
                    <label>From :</label>
                    <input type="date" id="add_from_date" class="additional-field" value="${additionalDetails.from_date}" ${disabledAttr} style="${disabledStyle}">
                    <label style="width: auto; margin-left: 15px; margin-right: 5px;">To :</label>
                    <input type="date" id="add_to_date" class="additional-field" value="${additionalDetails.to_date}" ${disabledAttr} style="${disabledStyle}">
                </div>
                <div class="field-row">
                    <label>Company :</label>
                    <input type="text" id="add_company_code" class="additional-field" value="${additionalDetails.company_code}" style="width: 80px; ${disabledStyle}" ${disabledAttr} placeholder="Code">
                    <input type="text" id="add_company_name" value="${additionalDetails.company_name}" readonly style="flex: 1; margin-left: 5px; background: #e9ecef;">
                </div>
                <div class="field-row">
                    <label>Division :</label>
                    <input type="text" id="add_division" class="additional-field" value="${additionalDetails.division}" style="width: 60px; ${disabledStyle}" ${disabledAttr}>
                </div>
                <div class="field-row" style="justify-content: flex-end; margin-top: 15px;">
                    <button type="button" class="ok-btn" onclick="saveAdditionalDetails()">Ok</button>
                </div>
            </div>
        </div>
    `;
    
    $('#additionalModal, #additionalModalBackdrop').remove();
    $('body').append(modalHTML);
    
    // Company code lookup
    $('#add_company_code').on('change', function() {
        const code = $(this).val();
        if (code) {
            $.get("{{ url('admin/companies/by-code') }}/" + code, function(response) {
                if (response.success) {
                    $('#add_company_name').val(response.company.name);
                } else {
                    $('#add_company_name').val('');
                }
            }).fail(function() { $('#add_company_name').val(''); });
        }
    });
    
    setTimeout(() => {
        $('#additionalModalBackdrop, #additionalModal').addClass('show');
        // Register keyboard handler for this modal
        window.removeEventListener('keydown', _handleAdditionalModalKey, true);
        window.addEventListener('keydown', _handleAdditionalModalKey, true);
        // Focus first field
        setTimeout(() => { document.getElementById('add_blank_statement')?.focus(); document.getElementById('add_blank_statement')?.select(); }, 80);
    }, 10);
}

function toggleAdditionalFields() {
    const blankValue = $('#add_blank_statement').val().toUpperCase();
    const isBlankY = blankValue === 'Y';
    
    if (isBlankY) {
        $('.additional-field').prop('disabled', true).css({ 'background': '#ccc', 'cursor': 'not-allowed' });
        $('#add_rate_type').val('R');
        $('#add_from_date').val('{{ date("Y-m-d") }}');
        $('#add_to_date').val('{{ date("Y-m-d") }}');
        $('#add_company_code').val('');
        $('#add_company_name').val('');
        $('#add_division').val('00');
    } else {
        $('.additional-field').prop('disabled', false).css({ 'background': '#fff', 'cursor': 'text' });
    }
}

function closeAdditionalDetailsModal() {
    window.removeEventListener('keydown', _handleAdditionalModalKey, true);
    $('#additionalModalBackdrop, #additionalModal').removeClass('show');
    setTimeout(() => { $('#additionalModal, #additionalModalBackdrop').remove(); }, 300);
}

function saveAdditionalDetails() {
    additionalDetails.blank_statement = $('#add_blank_statement').val().toUpperCase();
    additionalDetails.rate_type = $('#add_rate_type').val().toUpperCase();
    additionalDetails.from_date = $('#add_from_date').val();
    additionalDetails.to_date = $('#add_to_date').val();
    additionalDetails.company_code = $('#add_company_code').val();
    additionalDetails.company_name = $('#add_company_name').val();
    additionalDetails.division = $('#add_division').val();
    closeAdditionalDetailsModal();
    // Auto-open Add Item modal after additional details saved
    setTimeout(() => showAddItemModal(), 350);
}


// ==================== LEGACY ITEM SELECTION MODAL ====================
function _legacy_showAddItemModal() {
    const supplierId = $('#supplier_id').val();
    if (!supplierId) {
        alert('Please select a supplier first');
        return;
    }
    
    let params = { supplier_id: supplierId };
    if (additionalDetails.company_code) params.company_code = additionalDetails.company_code;
    if (additionalDetails.division && additionalDetails.division !== '00') params.division = additionalDetails.division;
    
    $.get("{{ route('admin.items.get-all') }}", params, function(data) {
        allItems = data.items || data;
        _legacy_showItemSelectionModal(allItems);
    }).fail(function() {
        alert('Failed to load items');
    });
}

function _legacy_showItemSelectionModal(items) {
    let itemsHtml = items.map((item, index) => {
        // Prepare item data with all required fields
        const itemData = {
            id: item.id,
            code: item.code || item.id,
            name: item.name || '',
            packing: item.packing || '',
            unit: item.unit || '',
            company_name: item.company_short_name || item.company_name || '',
            s_rate: item.s_rate || 0,
            ws_rate: item.ws_rate || 0,
            mrp: item.mrp || 0,
            pur_rate: item.pur_rate || 0,
            hsn_code: item.hsn_code || '',
            cgst_percent: item.cgst_percent || 0,
            sgst_percent: item.sgst_percent || 0,
            sc_percent: item.sc_percent || 0,
            scm_percent: item.scm_percent || 0,
            location: item.location || ''
        };
        return `
        <tr class="item-row" data-item-name="${(item.name || '').toLowerCase()}" data-item-code="${String(item.id).toLowerCase()}">
            <td style="text-align: center;">${index + 1}</td>
            <td>${item.id || ''}</td>
            <td>${item.name || ''}</td>
            <td>${item.company_short_name || ''}</td>
            <td style="text-align: center;">
                <button type="button" class="btn btn-sm btn-primary" onclick='_legacy_selectItem(${JSON.stringify(itemData).replace(/'/g, "\\'")})'
                    style="font-size: 9px; padding: 2px 8px;">Select</button>
            </td>
        </tr>
    `}).join('');
    
    const modalHTML = `
        <div class="modal-backdrop-custom" id="itemModalBackdrop" onclick="_legacy_closeItemModal()"></div>
        <div class="item-modal" id="itemModal">
            <div class="item-modal-header">
                <h5><i class="bi bi-box-seam me-2"></i>Select Item</h5>
                <button type="button" class="btn-close-custom" onclick="_legacy_closeItemModal()">&times;</button>
            </div>
            <div class="item-modal-body">
                <div style="margin-bottom: 10px;">
                    <input type="text" id="itemSearchInput" class="form-control form-control-sm" 
                           placeholder="Search by item name or code..." onkeyup="_legacy_filterItems()" style="font-size: 11px;">
                </div>
                <div style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-sm" style="font-size: 10px; margin-bottom: 0;">
                        <thead style="position: sticky; top: 0; background: #0d6efd; color: white; z-index: 10;">
                            <tr>
                                <th style="width: 35px; text-align: center;">S.N</th>
                                <th style="width: 80px;">Code</th>
                                <th style="width: 200px;">Item Name</th>
                                <th style="width: 120px;">Company</th>
                                <th style="width: 80px; text-align: center;">Action</th>
                            </tr>
                        </thead>
                        <tbody>${itemsHtml}</tbody>
                    </table>
                </div>
            </div>
            <div class="item-modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" onclick="_legacy_closeItemModal()">Close</button>
            </div>
        </div>
    `;
    
    $('#itemModal, #itemModalBackdrop').remove();
    $('body').append(modalHTML);
    setTimeout(() => { $('#itemModalBackdrop, #itemModal').addClass('show'); $('#itemSearchInput').focus(); }, 10);
}

function _legacy_filterItems() {
    const searchValue = $('#itemSearchInput').val().toLowerCase();
    $('.item-row').each(function() {
        const name = $(this).data('item-name');
        const code = $(this).data('item-code');
        $(this).toggle(name.includes(searchValue) || code.includes(searchValue));
    });
}

function _legacy_closeItemModal() {
    $('#itemModalBackdrop, #itemModal').removeClass('show');
    setTimeout(() => { $('#itemModal, #itemModalBackdrop').remove(); }, 300);
}

// ==================== LEGACY SELECT ITEM & ADD ROW (NO BATCH MODAL) ====================
function _legacy_selectItem(item) {
    if (typeof item === 'string') item = JSON.parse(item);
    selectedItem = item;
    _legacy_closeItemModal();
    
    // Directly add row without batch modal - user will enter batch manually
    _legacy_addItemRowManual(item);
}

function _legacy_addItemRowManual(item) {
    const row = `
        <tr data-row="${rowIndex}">
            <td><input type="text" class="form-control item-code" data-row="${rowIndex}" value="${item.code || ''}" readonly tabindex="-1"></td>
            <td><input type="text" class="form-control item-name" data-row="${rowIndex}" value="${item.name || ''}" readonly tabindex="-1"></td>
            <td><input type="text" class="form-control batch-no" data-row="${rowIndex}" value="" placeholder="Enter batch"></td>
            <td><input type="text" class="form-control expiry" data-row="${rowIndex}" value="" placeholder="MM/YY"></td>
            <td><input type="number" class="form-control qty" data-row="${rowIndex}" value="0" min="0"></td>
            <td><input type="number" class="form-control free-qty" data-row="${rowIndex}" value="0" min="0"></td>
            <td><input type="number" class="form-control rate" data-row="${rowIndex}" value="0" step="0.01"></td>
            <td><input type="number" class="form-control dis-percent" data-row="${rowIndex}" value="0" step="0.01"></td>
            <td><input type="number" class="form-control amount" data-row="${rowIndex}" value="0" step="0.01" readonly tabindex="-1"></td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-danger" onclick="removeRow(${rowIndex})" tabindex="-1"><i class="bi bi-trash"></i></button>
            </td>
        </tr>
    `;
    $('#itemsTableBody').append(row);
    
    const $row = $(`tr[data-row="${rowIndex}"]`);
    $row.data('item_id', item.id);
    $row.data('rate_charged', 0);
    $row.data('actual_rate', 0);
    // Store item data for later use
    const itemDataObj = {
        s_rate: parseFloat(item.s_rate) || 0,
        ws_rate: parseFloat(item.ws_rate) || 0,
        hsn_code: item.hsn_code || '',
        cgst_percent: parseFloat(item.cgst_percent) || 0,
        sgst_percent: parseFloat(item.sgst_percent) || 0,
        sc_percent: parseFloat(item.sc_percent) || 0,
        scm_percent: parseFloat(item.scm_percent) || 0,
        packing: item.packing || '',
        unit: item.unit || '',
        company_name: item.company_name || '',
        location: item.location || ''
    };
    console.log('Item received:', item);
    console.log('Item data stored:', itemDataObj);
    $row.data('item_data', itemDataObj);
    
    // Select this row and update all sections
    $('#itemsTableBody tr').removeClass('selected-row');
    $row.addClass('selected-row');
    
    // Update Calculation Section and Summary Section with this row's data
    updateSelectedRowDetails($row);
    
    // Update totals
    calculateTotals();
    
    // Focus on batch field
    setTimeout(() => {
        $row.find('.batch-no').focus();
    }, 100);
    
    rowIndex++;
}

// Update calculation fields when row is focused
function updateCalcFieldsFromRow($row) {
    const itemData = $row.data('item_data') || {};
    
    $('#calc_hsn_code').val(itemData.hsn_code || '');
    $('#calc_s_rate').val(parseFloat(itemData.s_rate || 0).toFixed(2));
    $('#calc_ws_rate').val(parseFloat(itemData.ws_rate || 0).toFixed(2));
    $('#calc_cgst_percent').val(itemData.cgst_percent || 0);
    $('#calc_sgst_percent').val(itemData.sgst_percent || 0);
    $('#packing').val(itemData.packing || '');
    $('#unit').val(itemData.unit || '');
    $('#companyName').val(itemData.company_name || '');
}

// Update calc fields when any input in row is focused - also select the row
$(document).on('focus', '#itemsTableBody tr input', function() {
    const $row = $(this).closest('tr');
    
    // Select this row
    $('#itemsTableBody tr').removeClass('selected-row');
    $row.addClass('selected-row');
    
    // Update all sections with this row's data
    updateSelectedRowDetails($row);
});

// Table row Enter-key navigation handled in master window capture handler below

// ==================== RATE CHARGED / ACTUAL RATE MODAL ====================
function showRateModal(rowIdx) {
    const $row = $(`tr[data-row="${rowIdx}"]`);
    const rateCharged = $row.data('rate_charged') || 0;
    const actualRate = $row.data('actual_rate') || 0;
    
    const modalHTML = `
        <div class="modal-backdrop-custom show" id="rateModalBackdrop" onclick="closeRateModal()"></div>
        <div class="rate-modal show" id="rateModal">
            <div class="rate-modal-header">
                <span>&#9998; Rate Details</span>
                <button type="button" onclick="closeRateModal()" style="background:none;border:none;color:white;font-size:18px;cursor:pointer;line-height:1;">&times;</button>
            </div>
            <div class="rate-modal-body">
                <div class="field-row">
                    <label>Rate Charged :</label>
                    <input type="number" id="rate_charged" class="yellow-bg" value="${rateCharged}" step="0.01">
                    <label>Actual Rate :</label>
                    <input type="number" id="actual_rate" value="${actualRate}" step="0.01">
                </div>
                <div class="field-row" style="justify-content: flex-end; margin-top: 5px;">
                    <button type="button" class="rate-ok-btn" onclick="saveRateModal()">Ok</button>
                </div>
            </div>
        </div>
    `;
    
    $('#rateModal, #rateModalBackdrop').remove();
    $('body').append(modalHTML);
    // Modal already has .show class in HTML, just focus and register handler
    setTimeout(() => {
        document.getElementById('rate_charged')?.focus();
        document.getElementById('rate_charged')?.select();
        window.removeEventListener('keydown', _handleRateModalKey, true);
        window.addEventListener('keydown', _handleRateModalKey, true);
    }, 30);
}

function saveRateModal() {
    const rateCharged = parseFloat($('#rate_charged').val()) || 0;
    const actualRate  = parseFloat($('#actual_rate').val())  || 0;
    
    if (currentRowForRate !== null) {
        const $row = $(`tr[data-row="${currentRowForRate}"]`);
        $row.data('rate_charged', rateCharged);
        $row.data('actual_rate',  actualRate);
        $row.find('.rate').val(rateCharged.toFixed(2));
        // Recalculate
        calculateRowAmount($row);
        calculateTotals();
    }
    
    // closeRateModal will handle focus back to .rate field
    closeRateModal();
    currentRowForRate = null;
}

function closeRateModal() {
    window.removeEventListener('keydown', _handleRateModalKey, true);
    $('#rateModal, #rateModalBackdrop').remove();
    // Capture value NOW before any null-setting
    const rowToFocus = currentRowForRate;
    if (rowToFocus !== null) {
        setTimeout(() => {
            const $r = $(`tr[data-row="${rowToFocus}"]`);
            if ($r.length) { $r.find('.rate').focus().select(); }
        }, 50);
    }
}


// ==================== ROW CALCULATIONS ====================
function removeRow(row) {
    $(`tr[data-row="${row}"]`).remove();
    calculateTotals();
}

$(document).on('change', '.qty, .free-qty, .rate, .dis-percent', function() {
    const $row = $(this).closest('tr');
    calculateRowAmount($row);
    calculateTotals();
});

// Row selection highlight and update selected row details
$(document).on('click', '#itemsTableBody tr', function(e) {
    // Don't select if clicking on input or button
    if ($(e.target).is('input, button, i')) return;
    
    $('#itemsTableBody tr').removeClass('selected-row');
    $(this).addClass('selected-row');
    
    // Update Calculation Section and Summary Section with selected row data
    updateSelectedRowDetails($(this));
});

// Update Calculation Section and Summary Section with selected row's item details
function updateSelectedRowDetails($row) {
    const itemId = $row.data('item_id');
    
    // If no item_id, just update with empty/zero values
    if (!itemId) {
        updateSectionsWithItemData($row, {});
        return;
    }
    
    // Fetch item data from Items table via API
    $.ajax({
        url: "{{ url('admin/items/search') }}",
        method: 'GET',
        data: { code: itemId },
        success: function(response) {
            if (response.success && response.items && response.items.length > 0) {
                const item = response.items[0];
                const itemData = {
                    hsn_code: item.hsn_code || '',
                    cgst_percent: parseFloat(item.cgst_percent) || 0,
                    sgst_percent: parseFloat(item.sgst_percent) || 0,
                    packing: item.packing || '',
                    unit: item.unit || '',
                    company_name: item.company || item.mfg_by || '',
                    location: item.location || '',
                    ws_rate: parseFloat(item.ws_rate) || 0,
                    s_rate: parseFloat(item.s_rate) || 0,
                    sc_percent: 0,
                    scm_percent: 0
                };
                // Store for future use
                $row.data('item_data', itemData);
                updateSectionsWithItemData($row, itemData);
            } else {
                updateSectionsWithItemData($row, $row.data('item_data') || {});
            }
        },
        error: function() {
            updateSectionsWithItemData($row, $row.data('item_data') || {});
        }
    });
}

// Helper function to update sections with item data
function updateSectionsWithItemData($row, itemData) {
    const qty = parseFloat($row.find('.qty').val()) || 0;
    const rate = parseFloat($row.find('.rate').val()) || 0;
    const disPercent = parseFloat($row.find('.dis-percent').val()) || 0;
    const amount = parseFloat($row.find('.amount').val()) || 0; // Amount = Qty × Rate
    
    const cgstPercent = parseFloat(itemData.cgst_percent) || 0;
    const sgstPercent = parseFloat(itemData.sgst_percent) || 0;
    const scPercent = parseFloat(itemData.sc_percent) || 0;
    const scmPercent = parseFloat(itemData.scm_percent) || 0;
    const taxPercent = cgstPercent + sgstPercent;
    
    // Calculate for this single row
    // N.T Amt = Amount (Qty × Rate)
    const ntAmt = amount;
    
    // Discount Amount = N.T Amt × Dis%
    const disAmount = ntAmt * disPercent / 100;
    
    // SC Amount = N.T Amt × SC%
    const scAmount = ntAmt * scPercent / 100;
    
    // SCM Amount = N.T Amt × SCM%
    const scmAmount = ntAmt * scmPercent / 100;
    
    // Net Amount = N.T Amt - DIS Amt
    const netAmount = ntAmt - disAmount;
    
    // Tax calculated on net amount
    const cgstAmount = netAmount * cgstPercent / 100;
    const sgstAmount = netAmount * sgstPercent / 100;
    const taxAmount = cgstAmount + sgstAmount;
    
    // Update Calculation Section (Item-based details)
    $('#calc_hsn_code').val(itemData.hsn_code || '');
    $('#calc_sc_percent').val(scPercent.toFixed(3));
    $('#calc_tax_percent').val(taxPercent.toFixed(3));
    $('#calc_cgst_percent').val(cgstPercent);
    $('#calc_cgst_amount').val(cgstAmount.toFixed(2));
    $('#calc_sgst_percent').val(sgstPercent);
    $('#calc_sgst_amount').val(sgstAmount.toFixed(2));
    $('#calc_ws_rate').val(parseFloat(itemData.ws_rate || 0).toFixed(2));
    $('#calc_s_rate').val(parseFloat(itemData.s_rate || 0).toFixed(2));
    
    // Update Summary Section (Item-based details)
    $('#packing').val(itemData.packing || '');
    $('#unit').val(itemData.unit || '');
    $('#companyName').val(itemData.company_name || '');
    $('#srlNo').val($row.data('row') !== undefined ? ($row.data('row') + 1) : '');
    $('#locationField').val(itemData.location || '');
    
    // Item-level amounts in Summary
    $('#ntAmount').val(ntAmt.toFixed(2));
    $('#scAmount').val(scAmount.toFixed(2));
    $('#scmAmount').val(scmAmount.toFixed(2));
    $('#disAmount').val(disAmount.toFixed(2));
    $('#taxAmount').val(taxAmount.toFixed(2));
    $('#invAmount').val(netAmount.toFixed(2));
    $('#clQty').val(qty);
}

function calculateRowAmount($row) {
    const qty = parseFloat($row.find('.qty').val()) || 0;
    const rate = parseFloat($row.find('.rate').val()) || 0;
    
    // Amount = Qty × Rate ONLY (no discount applied here)
    const amount = qty * rate;
    $row.find('.amount').val(amount.toFixed(2));
    
    // If this row is selected, update calculation and summary sections
    if ($row.hasClass('selected-row')) {
        updateSelectedRowDetails($row);
    }
}

// Calculate totals for all items (Totals Row Section - Pink)
function calculateTotals() {
    let totalNtAmount = 0;
    let totalCgstAmount = 0;
    let totalSgstAmount = 0;
    let totalDisAmount = 0;
    let totalScAmount = 0;
    let totalScmAmount = 0;
    let totalQty = 0;
    
    $('#itemsTableBody tr').each(function() {
        const $row = $(this);
        const qty = parseFloat($row.find('.qty').val()) || 0;
        const rate = parseFloat($row.find('.rate').val()) || 0;
        const disPercent = parseFloat($row.find('.dis-percent').val()) || 0;
        const amount = parseFloat($row.find('.amount').val()) || 0; // Amount = Qty × Rate
        const itemData = $row.data('item_data') || {};
        const cgstPercent = parseFloat(itemData.cgst_percent) || 0;
        const sgstPercent = parseFloat(itemData.sgst_percent) || 0;
        const scPercent = parseFloat(itemData.sc_percent) || 0;
        const scmPercent = parseFloat(itemData.scm_percent) || 0;
        
        // N.T Amount = Sum of all Amount (Qty × Rate)
        totalNtAmount += amount;
        
        // Discount Amount = Amount × Dis%
        const disAmount = amount * disPercent / 100;
        totalDisAmount += disAmount;
        
        // SC Amount = Amount × SC%
        const scAmount = amount * scPercent / 100;
        totalScAmount += scAmount;
        
        // SCM Amount = Amount × SCM%
        const scmAmount = amount * scmPercent / 100;
        totalScmAmount += scmAmount;
        
        // Tax calculated on amount after discount
        const amountAfterDiscount = amount - disAmount;
        totalCgstAmount += amountAfterDiscount * cgstPercent / 100;
        totalSgstAmount += amountAfterDiscount * sgstPercent / 100;
        totalQty += qty;
    });
    
    const totalTaxAmount = totalCgstAmount + totalSgstAmount;
    const totalInvAmount = (totalNtAmount - totalDisAmount) + totalTaxAmount;
    
    // Update Totals Row Section (Pink) - All items sum
    $('#total_nt_amt').val(totalNtAmount.toFixed(2));
    $('#total_sc').val(totalScAmount.toFixed(2));
    $('#total_dis_amt').val(totalDisAmount.toFixed(2));
    $('#total_scm_amt').val(totalScmAmount.toFixed(2));
    $('#total_tax').val(totalTaxAmount.toFixed(2));
    $('#total_inv_amt').val(totalInvAmount.toFixed(2));
    
    // If a row is selected, update its details, otherwise show totals in summary
    const $selectedRow = $('#itemsTableBody tr.selected-row');
    if ($selectedRow.length > 0) {
        updateSelectedRowDetails($selectedRow);
    }
}

// ==================== SAVE TRANSACTION ====================
function saveTransaction() {
    const supplierId = $('#supplier_id').val();
    if (!supplierId) {
        alert('Please select a supplier');
        return;
    }
    
    const items = [];
    $('#itemsTableBody tr').each(function() {
        const $row = $(this);
        const qty = parseFloat($row.find('.qty').val()) || 0;
        if (qty > 0) {
            const itemData = $row.data('item_data') || {};
            items.push({
                item_id: $row.data('item_id'),
                item_code: $row.find('.item-code').val(),
                item_name: $row.find('.item-name').val(),
                batch_no: $row.find('.batch-no').val(),
                expiry: $row.find('.expiry').val(),
                qty: qty,
                free_qty: parseFloat($row.find('.free-qty').val()) || 0,
                pur_rate: parseFloat($row.find('.rate').val()) || 0,
                dis_percent: parseFloat($row.find('.dis-percent').val()) || 0,
                ft_amount: parseFloat($row.find('.amount').val()) || 0,
                rate_charged: $row.data('rate_charged') || 0,
                actual_rate: $row.data('actual_rate') || 0,
                cgst_percent: itemData.cgst_percent || 0,
                sgst_percent: itemData.sgst_percent || 0,
                hsn_code: itemData.hsn_code || '',
                packing: itemData.packing || '',
                unit: itemData.unit || '',
                company_name: itemData.company_name || '',
                ws_rate: itemData.ws_rate || 0,
                s_rate: itemData.s_rate || 0,
                sc_percent: itemData.sc_percent || 0,
                scm_percent: itemData.scm_percent || 0,
            });
        }
    });
    
    if (items.length === 0) {
        alert('Please add at least one item');
        return;
    }
    
    const data = {
        _token: '{{ csrf_token() }}',
        claim_date: $('#claim_date').val(),
        supplier_id: supplierId,
        supplier_name: $('#supplier_id option:selected').text(),
        invoice_no: $('#invoice_no').val(),
        invoice_date: $('#invoice_date').val(),
        tax_flag: $('#tax_flag').val(),
        narration: $('#narration').val(),
        nt_amount: parseFloat($('#ntAmount').val()) || 0,
        tax_amount: parseFloat($('#taxAmount').val()) || 0,
        net_amount: parseFloat($('#invAmount').val()) || 0,
        // Additional Details
        blank_statement: additionalDetails.blank_statement,
        rate_type: additionalDetails.rate_type,
        filter_from_date: additionalDetails.from_date,
        filter_to_date: additionalDetails.to_date,
        company_code: additionalDetails.company_code,
        division: additionalDetails.division,
        // Reference Invoice Info
        ref_inv_no: $('#ref_inv_no').val(),
        ref_inv_date: $('#ref_inv_date').val(),
        ref_customer_code: $('#ref_customer_code').val(),
        ref_customer_name: $('#ref_customer_name').val(),
        items: items
    };
    
    $.ajax({
        url: "{{ route('admin.claim-to-supplier.store') }}",
        method: 'POST',
        data: data,
        success: function(response) {
            if (response.success) {
                alert('Claim saved successfully! Claim No: ' + response.claim_no);
                window.location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        },
        error: function(xhr) {
            alert('Error saving claim: ' + (xhr.responseJSON?.message || 'Unknown error'));
        }
    });
}

// ============================================================================
// SUPPLIER CUSTOM DROPDOWN
// ============================================================================
let _supplierHil = -1;

function _openSupplierDrop() {
    const dl = document.getElementById('supplierDropList');
    if (!dl) return;
    dl.style.display = 'block';
    // highlight current selected
    const cur = document.getElementById('supplier_id').value;
    const items = [...document.querySelectorAll('.supplier-drop-item')];
    let activeIdx = -1;
    items.forEach((el, i) => {
        const visible = el.style.display !== 'none';
        const active  = el.dataset.value === cur && visible;
        el.style.background = active ? '#0d6efd' : '';
        el.style.color      = active ? '#fff'    : '';
        if (active) activeIdx = i;
    });
    if (activeIdx >= 0) _supplierHil = activeIdx;
    else if (items.filter(el => el.style.display !== 'none').length) _highlightSupplier(0);
}

function _closeSupplierDrop() {
    const dl = document.getElementById('supplierDropList');
    if (dl) dl.style.display = 'none';
    _supplierHil = -1;
}

function _filterSupplierList() {
    const q = (document.getElementById('supplier_search')?.value || '').toLowerCase();
    const items = document.querySelectorAll('.supplier-drop-item');
    let firstVisible = -1;
    items.forEach((el, i) => {
        const match = el.dataset.name.toLowerCase().includes(q);
        el.style.display = match ? '' : 'none';
        if (match && firstVisible < 0) firstVisible = i;
    });
    _supplierHil = -1;
    const dl = document.getElementById('supplierDropList');
    if (dl && dl.style.display === 'none') dl.style.display = 'block';
    if (firstVisible >= 0) _highlightSupplier(firstVisible);
}

function _highlightSupplier(idx) {
    const items = [...document.querySelectorAll('.supplier-drop-item')].filter(el => el.style.display !== 'none');
    items.forEach((el, i) => {
        el.style.background = i === idx ? '#0d6efd' : '';
        el.style.color      = i === idx ? '#fff'    : '';
    });
    _supplierHil = idx;
    // Scroll INSIDE dropdown container only — scrollIntoView scrolls the whole page!
    if (items[idx]) {
        const container = document.getElementById('supplierDropList');
        if (container) {
            const itemTop    = items[idx].offsetTop;
            const itemBottom = itemTop + items[idx].offsetHeight;
            if (itemBottom > container.scrollTop + container.clientHeight) {
                container.scrollTop = itemBottom - container.clientHeight;
            } else if (itemTop < container.scrollTop) {
                container.scrollTop = itemTop;
            }
        }
    }
}

function _selectSupplierItem(el) {
    document.getElementById('supplier_id').value     = el.dataset.value;
    document.getElementById('supplier_search').value = el.dataset.name;
    _closeSupplierDrop();
    setTimeout(() => {
        const f = document.getElementById('invoice_date');
        if (f) f.focus();
    }, 50);
}

// Close supplier drop on outside click
document.addEventListener('click', function(e) {
    if (!e.target.closest('#supplierWrapper')) _closeSupplierDrop();
});

// ============================================================================
// ADDITIONAL DETAILS MODAL — KEYBOARD HANDLER
// ============================================================================
function _handleAdditionalModalKey(e) {
    const modal = document.getElementById('additionalModal');
    if (!modal || !modal.classList.contains('show')) return;

    if (!['Enter', 'Escape', 'Tab'].includes(e.key)) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();

    if (e.key === 'Escape') { closeAdditionalDetailsModal(); return; }

    if (e.key === 'Enter' || e.key === 'Tab') {
        const el = document.activeElement;

        if (el?.id === 'add_blank_statement') {
            toggleAdditionalFields();
            const blank = document.getElementById('add_blank_statement')?.value?.toUpperCase() === 'Y';
            if (blank) {
                // Y selected + all fields disabled → directly OK
                saveAdditionalDetails();
            } else {
                const rt = document.getElementById('add_rate_type');
                if (rt) { rt.focus(); rt.select(); }
            }
            return;
        }
        if (el?.id === 'add_rate_type') {
            document.getElementById('add_from_date')?.focus();
            return;
        }
        if (el?.id === 'add_from_date') {
            document.getElementById('add_to_date')?.focus();
            return;
        }
        if (el?.id === 'add_to_date') {
            const cc = document.getElementById('add_company_code');
            if (cc) { cc.focus(); cc.select(); }
            return;
        }
        if (el?.id === 'add_company_code') {
            const code = el.value;
            if (code) {
                $.get("{{ url('admin/companies/by-code') }}/" + code, function(response) {
                    if (response.success) $('#add_company_name').val(response.company.name);
                    else $('#add_company_name').val('');
                }).fail(() => $('#add_company_name').val(''));
            }
            const dv = document.getElementById('add_division');
            if (dv) { dv.focus(); dv.select(); }
            return;
        }
        if (el?.id === 'add_division') {
            saveAdditionalDetails(); // closes modal + opens Add Item
            return;
        }
        // fallback: ok button
        saveAdditionalDetails();
    }
}

// ============================================================================
// RATE MODAL — KEYBOARD HANDLER
// ============================================================================
function _handleRateModalKey(e) {
    const modal = document.getElementById('rateModal');
    if (!modal || !modal.classList.contains('show')) return;

    if (!['Enter', 'Escape'].includes(e.key)) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();

    if (e.key === 'Escape') { closeRateModal(); return; }

    if (e.key === 'Enter') {
        const el = document.activeElement;
        if (el?.id === 'rate_charged') {
            const ar = document.getElementById('actual_rate');
            if (ar) { ar.focus(); ar.select(); }
        } else {
            saveRateModal();
        }
    }
}

// Rate modal keyboard handlers are registered directly inside showRateModal/closeRateModal above

// ============================================================================
// HELPERS — modal open checks
// ============================================================================
function _anyItemModalOpen() {
    return !!document.querySelector('#claimToSupplierItemModal.show, #claimToSupplierBatchModal.show');
}
function _additionalModalOpen() {
    const m = document.getElementById('additionalModal');
    return !!(m && m.classList.contains('show'));
}
function _rateModalOpen() {
    const m = document.getElementById('rateModal');
    return !!(m && m.classList.contains('show'));
}

// ============================================================================
// PAGE LOAD — focus claim_date
// ============================================================================
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        const cd = document.getElementById('claim_date');
        if (cd) cd.focus();
    }, 300);
});

// ============================================================================
// MASTER KEYBOARD HANDLER — window capture phase
// Flow:
//   Header : claim_date → supplier_search → invoice_date → tax_flag → narration → Additional Details modal
//   Add. modal: _handleAdditionalModalKey → division Enter → save → showAddItemModal
//   Table  : batch-no → expiry → qty → free-qty → [Rate modal] → rate → dis% → showAddItemModal (loop)
//   Ctrl+S : saveTransaction
// ============================================================================
window.addEventListener('keydown', function(e) {

    // ── Supplier dropdown open → intercept nav keys ───────────────────────
    const suppDrop = document.getElementById('supplierDropList');
    const suppOpen = suppDrop && suppDrop.style.display !== 'none';
    if (suppOpen && document.activeElement?.id === 'supplier_search') {
        if (['ArrowDown', 'ArrowUp', 'Enter', 'Escape'].includes(e.key)) {
            e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
            const visibles = [...document.querySelectorAll('.supplier-drop-item')].filter(el => el.style.display !== 'none');
            if (!visibles.length) return;
            if (e.key === 'Escape') { _closeSupplierDrop(); return; }
            if (e.key === 'ArrowDown') { _highlightSupplier((_supplierHil + 1) % visibles.length); return; }
            if (e.key === 'ArrowUp')   { _highlightSupplier((_supplierHil - 1 + visibles.length) % visibles.length); return; }
            if (e.key === 'Enter') {
                if (_supplierHil >= 0 && visibles[_supplierHil]) _selectSupplierItem(visibles[_supplierHil]);
                else if (visibles.length) _selectSupplierItem(visibles[0]);
                return;
            }
        }
    }

    // ── Additional details modal — handled by its own handler ─────────────
    if (_additionalModalOpen()) return;

    // ── Rate modal — handled by its own handler ───────────────────────────
    if (_rateModalOpen()) return;

    // ── Item / Batch modals open → skip ──────────────────────────────────
    if (_anyItemModalOpen()) return;

    // ── Ctrl+S → Save Transaction ─────────────────────────────────────────
    if (e.key === 's' && e.ctrlKey && !e.shiftKey && !e.altKey) {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        saveTransaction();
        return;
    }

    if (e.key !== 'Enter') return;

    const el = document.activeElement;
    if (!el) return;

    // ── SHIFT+ENTER: BACKWARD NAVIGATION (all fields) ─────────────────────
    if (e.shiftKey) {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();

        // Header backward: narration → tax_flag → invoice_date → supplier → claim_date
        if (el.id === 'narration')      { const tf = document.getElementById('tax_flag'); if (tf) { tf.focus(); tf.select(); } return; }
        if (el.id === 'tax_flag')       { const id = document.getElementById('invoice_date'); if (id) id.focus(); return; }
        if (el.id === 'invoice_date')   { const ss = document.getElementById('supplier_search'); if (ss) { ss.focus(); ss.select(); } return; }
        if (el.id === 'supplier_search'){ const cd = document.getElementById('claim_date'); if (cd) cd.focus(); return; }

        // Table backward
        const $el  = $(el);
        const $row = $el.closest('#itemsTableBody tr');
        if (!$row.length) return;

        if ($el.hasClass('dis-percent')) { $row.find('.rate').focus().select(); return; }
        if ($el.hasClass('rate'))        { $row.find('.free-qty').focus().select(); return; }
        if ($el.hasClass('free-qty'))    { $row.find('.qty').focus().select(); return; }
        if ($el.hasClass('qty'))         { $row.find('.expiry').focus().select(); return; }
        if ($el.hasClass('expiry'))      { $row.find('.batch-no').focus().select(); return; }
        if ($el.hasClass('batch-no')) {
            const $prevRow = $row.prev('tr');
            if ($prevRow.length) { $prevRow.find('.dis-percent').focus().select(); }
            else { const nr = document.getElementById('narration'); if (nr) nr.focus(); }
            return;
        }
        return;
    }

    // ── HEADER FIELDS (forward) ───────────────────────────────────────────

    // claim_date → supplier_search (open dropdown)
    if (el.id === 'claim_date') {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        const sf = document.getElementById('supplier_search');
        if (sf) { sf.focus(); sf.select(); }
        setTimeout(() => _openSupplierDrop(), 30);
        return;
    }

    // supplier_search (no dropdown) → open dropdown
    if (el.id === 'supplier_search' && !suppOpen) {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        _openSupplierDrop();
        return;
    }

    // invoice_date → tax_flag
    if (el.id === 'invoice_date') {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        const tf = document.getElementById('tax_flag');
        if (tf) { tf.focus(); tf.select(); }
        return;
    }

    // tax_flag → narration
    if (el.id === 'tax_flag') {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        const nf = document.getElementById('narration');
        if (nf) nf.focus();
        return;
    }

    // narration → open Additional Details modal
    if (el.id === 'narration') {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        showAdditionalDetailsModal();
        return;
    }

    // ── TABLE ROW FIELDS ──────────────────────────────────────────────────

    const $el  = $(el);
    const $row = $el.closest('#itemsTableBody tr');
    if (!$row.length) return;

    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();

    // ── Enter: forward navigation ─────────────────────────────────────────
    if ($el.hasClass('batch-no')) {
        $row.find('.expiry').focus().select();
        return;
    }
    if ($el.hasClass('expiry')) {
        $row.find('.qty').focus().select();
        return;
    }
    if ($el.hasClass('qty')) {
        const qtyVal = parseFloat($el.val()) || 0;
        if (qtyVal === 0) {
            alert('Qty cannot be 0');
            $el.focus().select();
            return;
        }
        $row.find('.free-qty').focus().select();
        return;
    }
    if ($el.hasClass('free-qty')) {
        // Validate Qty + F.Qty sum must be a whole number
        const qtyVal = parseFloat($row.find('.qty').val()) || 0;
        const fQtyVal = parseFloat($el.val()) || 0;
        const sum = qtyVal + fQtyVal;
        const rounded = Math.round(sum * 10000) / 10000;
        if (rounded % 1 !== 0) {
            window._fqtyValidating = true;
            alert('Qty + F.Qty must be a whole number (current sum: ' + sum.toFixed(2) + ')');
            setTimeout(function() { window._fqtyValidating = false; $el.focus().select(); }, 50);
            return;
        }
        const rowIdx = $row.data('row');
        currentRowForRate = rowIdx;
        showRateModal(rowIdx);
        return;
    }
    if ($el.hasClass('rate')) {
        $row.find('.dis-percent').focus().select();
        return;
    }
    if ($el.hasClass('dis-percent')) {
        // Calculate row → totals → loop back to Add Item
        calculateRowAmount($row);
        calculateTotals();
        setTimeout(() => showAddItemModal(), 50);
        return;
    }

}, true); // ← capture phase — fires BEFORE layout's document handlers

// focusout validation removed — Enter key validation in master handler is sufficient
</script>

<script>
// ============================================================
// AUTO-SAVE  —  claim_to_supplier_transaction_autosave_v1
// ============================================================
(function(){
'use strict';
const KEY = 'claim_to_supplier_transaction_autosave_v1';
let _t = null;

function _val(id){ const el=document.getElementById(id); return el?el.value:''; }
function _set(id,v){ const el=document.getElementById(id); if(el) el.value=v; }
function _esc(v){ if(v===undefined||v===null)return''; return String(v).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function save(){
    const rows=[];
    document.querySelectorAll('#itemsTableBody tr').forEach(function(tr){
        const ri = tr.getAttribute('data-row');
        if(ri===null||ri==='') return;
        const gc = function(cls){ const el=tr.querySelector('.'+cls); return el?el.value:''; };
        const gh = function(n){ const el=tr.querySelector('[name="items['+ri+']['+n+']"]'); return el?el.value:''; };
        if(!gc('item-code')&&!gc('item-name')) return;
        // Save jQuery item_data if available
        let itemDataJson = '{}';
        try{
            const jqData = (typeof $!=='undefined') ? $('[data-row="'+ri+'"]').data('item_data') : null;
            if(jqData) itemDataJson = JSON.stringify(jqData);
        }catch(e){}
        rows.push({
            ri:ri,
            itemId: gh('item_id'), batchId: gh('batch_id'),
            code:gc('item-code'), name:gc('item-name'), batch:gc('batch-no'), expiry:gc('expiry'),
            qty:gc('qty'), free_qty:gc('free-qty'), rate:gc('rate'),
            dis_percent:gc('dis-percent'), amount:gc('amount'),
            item_id:gh('item_id'), batch_id:gh('batch_id'), hsn_code:gh('hsn_code'),
            packing:gh('packing'), unit:gh('unit'), company_name:gh('company_name'),
            mrp:gh('mrp'), s_rate:gh('s_rate'), pur_rate:gh('pur_rate'),
            itemDataJson: itemDataJson,
        });
    });

    const state={
        savedAt:new Date().toISOString(),
        claim_date:_val('claim_date'),
        supplier_id:_val('supplier_id'),
        supplier_search:_val('supplier_search'),
        invoice_date:_val('invoice_date'),
        tax_flag:_val('tax_flag'),
        narration:_val('narration'),
        ref_inv_no:_val('ref_inv_no'),
        ref_inv_date:_val('ref_inv_date'),
        ref_customer_code:_val('ref_customer_code'),
        ref_customer_name:_val('ref_customer_name'),
        rows:rows,
    };
    if(!state.supplier_id && !rows.length) return;
    try{ localStorage.setItem(KEY,JSON.stringify(state)); }catch(e){}
    _badge();
}
function _sched(){ clearTimeout(_t); _t=setTimeout(save,700); }

function restore(){
    let state; try{ const r=localStorage.getItem(KEY); if(!r)return; state=JSON.parse(r); }catch(e){return;}
    if(!state||(!state.supplier_id&&!state.rows.length)) return;
    _banner(state.savedAt, function keep(){
        if(state.claim_date) _set('claim_date',state.claim_date);
        _set('supplier_id',state.supplier_id||'');
        const ss=document.getElementById('supplier_search'); if(ss) ss.value=state.supplier_search||'';
        if(state.invoice_date) _set('invoice_date',state.invoice_date);
        _set('tax_flag',state.tax_flag||'Y');
        _set('narration',state.narration||'');
        _set('ref_inv_no',state.ref_inv_no||'');
        if(state.ref_inv_date) _set('ref_inv_date',state.ref_inv_date);
        _set('ref_customer_code',state.ref_customer_code||'');
        _set('ref_customer_name',state.ref_customer_name||'');

        const tbody=document.getElementById('itemsTableBody');
        if(tbody) tbody.innerHTML='';
        if(typeof rowIndex!=='undefined') window.rowIndex=0;

        (state.rows||[]).forEach(function(saved){
            const ri=saved.ri;
            if(typeof rowIndex!=='undefined'&&parseInt(ri)>=rowIndex) window.rowIndex=parseInt(ri)+1;
            const tr=document.createElement('tr');
            tr.id='row-'+ri;
            tr.setAttribute('data-row',ri);
            tr.onclick=function(){ if(typeof selectRow==='function') selectRow(parseInt(ri)); };
            tr.innerHTML=
                '<td><input type="text" class="form-control item-code" value="'+_esc(saved.code)+'" readonly tabindex="-1"></td>'+
                '<td><input type="text" class="form-control item-name" value="'+_esc(saved.name)+'" readonly tabindex="-1"></td>'+
                '<td><input type="text" class="form-control batch-no" value="'+_esc(saved.batch)+'" readonly tabindex="-1"></td>'+
                '<td><input type="text" class="form-control expiry" value="'+_esc(saved.expiry)+'" readonly tabindex="-1"></td>'+
                '<td><input type="number" class="form-control qty" data-row="'+ri+'" value="'+_esc(saved.qty||1)+'" step="0.01" min="0"></td>'+
                '<td><input type="number" class="form-control free-qty" data-row="'+ri+'" value="'+_esc(saved.free_qty||0)+'" min="0"></td>'+
                '<td><input type="number" class="form-control rate" data-row="'+ri+'" value="'+parseFloat(saved.rate||0).toFixed(2)+'" step="0.01"></td>'+
                '<td><input type="number" class="form-control dis-percent" data-row="'+ri+'" value="'+_esc(saved.dis_percent||0)+'" step="0.01"></td>'+
                '<td><input type="number" class="form-control amount readonly-field" value="'+_esc(saved.amount||'')+'" step="0.01" readonly tabindex="-1"></td>'+
                '<td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow('+ri+')" tabindex="-1"><i class="bi bi-x"></i></button></td>'+
                '<input type="hidden" name="items['+ri+'][item_id]" value="'+_esc(saved.item_id)+'">'+
                '<input type="hidden" name="items['+ri+'][batch_id]" value="'+_esc(saved.batch_id)+'">'+
                '<input type="hidden" name="items['+ri+'][hsn_code]" value="'+_esc(saved.hsn_code)+'">'+
                '<input type="hidden" name="items['+ri+'][packing]" value="'+_esc(saved.packing)+'">'+
                '<input type="hidden" name="items['+ri+'][unit]" value="'+_esc(saved.unit)+'">'+
                '<input type="hidden" name="items['+ri+'][company_name]" value="'+_esc(saved.company_name)+'">'+
                '<input type="hidden" name="items['+ri+'][mrp]" value="'+_esc(saved.mrp||0)+'">'+
                '<input type="hidden" name="items['+ri+'][s_rate]" value="'+_esc(saved.s_rate||0)+'">'+
                '<input type="hidden" name="items['+ri+'][pur_rate]" value="'+_esc(saved.pur_rate||0)+'">';
            if(tbody) tbody.appendChild(tr);
            // Restore jQuery .data() so saveTransaction() can read it
            try{
                const $r=(typeof $!=='undefined')?$('[data-row="'+ri+'"]'):null;
                if($r){
                    $r.data('item_id', saved.item_id||'');
                    $r.data('rate_charged', 0);
                    $r.data('actual_rate', 0);
                    try{ $r.data('item_data', JSON.parse(saved.itemDataJson||'{}')); }catch(e){ $r.data('item_data',{}); }
                }
            }catch(e){}
        });

        if(typeof calculateTotals==='function') calculateTotals();
    }, function discard(){ clearAutoSave(); });
}

window.clearAutoSave=function(){ try{ localStorage.removeItem(KEY); }catch(e){} };

function _badge(){
    let b=document.getElementById('_asBadge');
    if(!b){ b=document.createElement('div'); b.id='_asBadge';
      b.style.cssText='position:fixed;bottom:18px;right:18px;background:#198754;color:#fff;padding:5px 12px;border-radius:20px;font-size:11px;z-index:9999;opacity:0;transition:opacity 0.3s;pointer-events:none;';
      document.body.appendChild(b); }
    b.textContent='\u2713 Draft saved'; b.style.opacity='1';
    setTimeout(function(){ b.style.opacity='0'; },2200);
}
function _banner(savedAt,onKeep,onDiscard){
    const old=document.getElementById('_asBanner'); if(old) old.remove();
    const t=savedAt?new Date(savedAt).toLocaleTimeString():'';
    const d=document.createElement('div'); d.id='_asBanner';
    d.style.cssText='position:fixed;top:10px;left:calc(240px + 50%);transform:translateX(-50%);background:#fff3cd;border:1px solid #ffc107;padding:8px 16px;border-radius:6px;z-index:9999;display:flex;align-items:center;gap:10px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,0.15);';
    d.innerHTML='<span>\uD83D\uDCCB Unsaved draft restored'+(t?' ('+t+')':'')+' </span>'+
        '<button id="_asKeep" style="background:#198754;color:#fff;border:none;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:11px;">Keep</button>'+
        '<button id="_asDiscard" style="background:#dc3545;color:#fff;border:none;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:11px;">Discard</button>';
    document.body.appendChild(d);
    let done=false;
    function dismiss(){ if(done)return; done=true; d.remove(); }
    document.getElementById('_asKeep').onclick=function(){ dismiss(); if(onKeep) onKeep(); };
    document.getElementById('_asDiscard').onclick=function(){ dismiss(); if(onDiscard) onDiscard(); };
    setTimeout(function(){ if(!done){ dismiss(); if(onKeep) onKeep(); } },12000);
}

document.addEventListener('DOMContentLoaded',function(){
    setTimeout(function(){
        const _origReload=window.location.reload.bind(window.location);
        window.location.reload=function(){ clearAutoSave(); _origReload(); };
    },800);
    setTimeout(restore,900);
    const form=document.getElementById('ctsForm');
    if(form){ form.addEventListener('input',_sched); form.addEventListener('change',_sched); }
    const tbody=document.getElementById('itemsTableBody');
    if(tbody) new MutationObserver(_sched).observe(tbody,{childList:true,subtree:true});
});
})();
</script>

@endpush