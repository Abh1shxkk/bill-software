@extends('layouts.admin')

@section('title', 'Godown Breakage/Expiry - Modification')

@push('styles')
<style>
    .gbe-form { font-size: 11px; }
    .gbe-form label { font-weight: 600; font-size: 11px; margin-bottom: 0; white-space: nowrap; }
    .gbe-form input, .gbe-form select { font-size: 11px; padding: 2px 6px; height: 26px; }
    .header-section { background: white; border: 1px solid #dee2e6; padding: 10px; margin-bottom: 8px; border-radius: 4px; }
    .field-group { display: flex; align-items: center; gap: 6px; }
    .table-compact { font-size: 10px; margin-bottom: 0; }
    .table-compact th, .table-compact td { padding: 4px; vertical-align: middle; height: 45px; }
    .table-compact th { background: #87CEEB; font-weight: 600; text-align: center; border: 1px solid #dee2e6; }
    .table-compact input, .table-compact select { font-size: 10px; padding: 2px 4px; height: 22px; border: 1px solid #ced4da; width: 100%; }
    .readonly-field { background-color: #e9ecef !important; cursor: not-allowed; }
    .summary-section { background: #ffcccc; padding: 5px 10px; }
    .footer-section { background: #ffe4b5; padding: 8px; }
    .row-selected { background-color: #d4edff !important; outline: 2px solid #007bff !important; outline-offset: -2px; }
    .row-complete { background-color: #d4edda !important; }
    .batch-modal-backdrop { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 1050; }
    .batch-modal-backdrop.show { display: block; }
    .batch-modal { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 90%; max-width: 800px; z-index: 1055; background: white; border-radius: 8px; }
    .batch-modal.show { display: block; }
    .modal-header-custom { padding: 1rem; background: #17a2b8; color: white; display: flex; justify-content: space-between; align-items: center; }
    .modal-body-custom { padding: 1rem; max-height: 400px; overflow-y: auto; }
    .modal-footer-custom { padding: 1rem; background: #f8f9fa; border-top: 1px solid #dee2e6; text-align: right; }
    .item-row:hover, .batch-row:hover, .invoice-row:hover { background-color: #e3f2fd !important; cursor: pointer; }

    /* Custom Br/Ex Dropdown */
    .brex-dropdown { position: relative; display: inline-block; width: 50px; }
    .brex-dropdown .brex-display { font-size: 10px; padding: 1px 2px; height: 22px; border: 1px solid #ced4da; width: 50px; background: #fff; cursor: pointer; text-align: center; font-weight: 600; border-radius: 3px; }
    .brex-dropdown .brex-display:focus { border-color: #86b7fe; outline: 0; box-shadow: 0 0 0 0.15rem rgba(13,110,253,.25); }
    .brex-dropdown .brex-list { display: none; position: absolute; top: 100%; left: 0; width: 50px; background: white; border: 1px solid #0d6efd; z-index: 9999; box-shadow: 0 2px 8px rgba(0,0,0,0.25); border-radius: 0 0 4px 4px; }
    .brex-dropdown .brex-list.show { display: block; }
    .brex-dropdown .brex-option { padding: 3px 4px; cursor: pointer; font-size: 10px; text-align: center; font-weight: 600; border-bottom: 1px solid #eee; background: white; }
    .brex-dropdown .brex-option:last-child { border-bottom: none; }
    .brex-dropdown .brex-option:hover, .brex-dropdown .brex-option.active { background-color: #cfe2ff; color: #0d6efd; }
    .brex-dropdown .brex-option.selected { background-color: #d1e7dd; color: #0f5132; }
    .brex-td { overflow: visible !important; position: relative; text-align: center; }
    .table-responsive.brex-open { overflow: visible !important; }

    /* ── MOBILE RESPONSIVE ── */
@media (max-width: 767px) {

    body { overflow-x: hidden !important; }
    .card-body { padding: 8px !important; }

    /* ── Page title row ── */
    .d-flex.justify-content-between.align-items-center.mb-3 {
        flex-wrap: wrap !important;
        gap: 8px !important;
    }
    .d-flex.justify-content-between.align-items-center.mb-3 > div:last-child {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 4px !important;
        width: 100% !important;
    }
    .d-flex.justify-content-between.align-items-center.mb-3 .btn {
        flex: 1 1 calc(50% - 4px) !important;
        text-align: center !important;
    }

    /* ── Header: col-md-* → 100% ── */
    .header-section .row.g-2 > [class*="col-md-"] {
        flex: 0 0 100% !important;
        max-width: 100% !important;
    }
    .header-section .field-group {
        flex-wrap: nowrap !important;
    }
    .header-section .field-group input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── Items Table → horizontal scroll ── */
    #itemsTableContainer {
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch !important;
    }
    #itemsTableContainer .table-compact { min-width: 600px !important; }

    /* ── Summary → full width ── */
    .summary-section.mb-2.d-flex.justify-content-end {
        justify-content: stretch !important;
    }
    .summary-section .field-group {
        width: 100% !important;
    }
    .summary-section .field-group input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }

    /* ── Footer: col-md-* → 50% (2-per-row) ── */
    .footer-section .row.g-2 > [class*="col-md-"] {
        flex: 0 0 50% !important;
        max-width: 50% !important;
    }
    /* Transaction: nested col-6 inside col-md-4 → stay as-is (already 50%) */
    .footer-section .col-md-4 .row.g-2 > .col-6 {
        flex: 0 0 50% !important;
        max-width: 50% !important;
    }
    .footer-section .field-group input {
        flex: 1 !important;
        width: auto !important;
        min-width: 0 !important;
    }
    /* Srlno col — text-end reset on mobile */
    .footer-section .col-md-4.text-end {
        text-align: left !important;
    }
    .footer-section .col-md-4.text-end .field-group {
        justify-content: flex-start !important;
    }

    /* ── Action Buttons → wrap ── */
    .d-flex.justify-content-between.mt-3 {
        flex-wrap: wrap !important;
        gap: 8px !important;
    }
    .d-flex.justify-content-between.mt-3 > div {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 6px !important;
        width: 100% !important;
    }
    .d-flex.justify-content-between.mt-3 .btn {
        flex: 1 !important;
        padding: 10px 4px !important;
        text-align: center !important;
    }

    .toast-container { left: 10px !important; right: 10px !important; max-width: calc(100vw - 20px) !important; }
}
</style>
@endpush

@section('content')
<section class="gbe-form py-3">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h4 class="mb-0"><i class="bi bi-pencil-square me-2"></i> Godown Breakage/Expiry - Modification</h4>
                <div class="text-muted small">Load and modify existing transaction</div>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-warning btn-sm" id="gbem_loadInvoiceBtn" onclick="showLoadInvoiceModal()">
                    <i class="bi bi-folder2-open me-1"></i> Load Invoice
                </button>
                <a href="{{ route('admin.godown-breakage-expiry.index') }}" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-list me-1"></i> View All
                </a>
                <a href="{{ route('admin.godown-breakage-expiry.create') }}" class="btn btn-success btn-sm">
                    <i class="bi bi-plus-circle me-1"></i> New Transaction
                </a>
            </div>
        </div>

        <div class="card shadow-sm border-0 rounded">
            <div class="card-body">
                <form id="gbeForm" method="POST" autocomplete="off">
                    @csrf
                    @method('PUT')
                    <input type="hidden" id="transaction_id" name="transaction_id" value="">
                    
                    <div class="header-section">
                        <div class="row g-2 mb-2">
                            <div class="col-md-2">
                                <div class="field-group">
                                    <label style="width: 40px;">Date :</label>
                                    <input type="date" id="transaction_date" name="transaction_date" class="form-control" value="{{ date('Y-m-d') }}" onchange="updateDayName()" required data-custom-enter>
                                </div>
                                <div class="field-group mt-1">
                                    <label style="width: 40px;"></label>
                                    <input type="text" id="day_name" name="day_name" class="form-control readonly-field text-center" value="{{ date('l') }}" readonly style="width: 100px;">
                                </div>
                                <div class="field-group mt-1">
                                    <label style="width: 50px;">Trn.No :</label>
                                    <input type="text" id="trn_no" name="trn_no" class="form-control readonly-field" value="" readonly style="width: 100px;">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="field-group">
                                    <label style="width: 70px;">Narration :</label>
                                    <input type="text" id="narration" name="narration" class="form-control" data-custom-enter>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white border rounded p-2 mb-2">
                        <div class="table-responsive" style="max-height: 350px; overflow-y: auto;" id="itemsTableContainer">
                            <table class="table table-bordered table-compact">
                                <thead style="position: sticky; top: 0; z-index: 10;">
                                    <tr>
                                        <th style="width: 70px;">Code</th>
                                        <th style="width: 200px;">Item Name</th>
                                        <th style="width: 90px;">Batch</th>
                                        <th style="width: 70px;">Expiry</th>
                                        <th style="width: 70px;">Br/Ex</th>
                                        <th style="width: 60px;">Qty</th>
                                        <th style="width: 80px;">Cost</th>
                                        <th style="width: 100px;">Amount</th>
                                        <th style="width: 40px;">X</th>
                                    </tr>
                                </thead>
                                <tbody id="itemsTableBody"></tbody>
                            </table>
                        </div>
                        <div class="text-center mt-2 d-flex justify-content-center gap-2">
                            <button type="button" class="btn btn-sm btn-primary" id="gbem_addItemsBtn" onclick="showItemSelectionModal()"><i class="bi bi-search"></i> Add Items</button>
                        </div>
                    </div>

                    <div class="summary-section mb-2 d-flex justify-content-end">
                        <div class="field-group">
                            <label>Total :</label>
                            <input type="text" id="total_amount" name="total_amount" class="form-control readonly-field text-end" style="width: 150px;" value="0.00" readonly>
                        </div>
                    </div>

                    <div class="footer-section">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <div class="field-group mb-1"><label style="width: 50px;">Packing :</label><input type="text" id="packing" class="form-control readonly-field" readonly></div>
                                <div class="field-group mb-1"><label style="width: 50px;">Unit :</label><input type="text" id="unit" class="form-control readonly-field" readonly></div>
                                <div class="field-group"><label style="width: 50px;">Cl.Qty :</label><input type="text" id="cl_qty" class="form-control readonly-field text-end" value="0" readonly></div>
                            </div>
                            <div class="col-md-4">
                                <div class="field-group mb-1"><label style="width: 50px;">Pur.Rate :</label><input type="text" id="p_rate" class="form-control readonly-field text-end" readonly></div>
                                <div class="field-group mb-1"><label style="width: 50px;">S.Rate :</label><input type="text" id="s_rate" class="form-control readonly-field text-end" readonly></div>
                                <div class="field-group"><label style="width: 50px;">Mrp :</label><input type="text" id="mrp" class="form-control readonly-field text-end" readonly></div>
                            </div>
                            <div class="col-md-4 text-end">
                                <div class="field-group justify-content-end"><label style="width: 40px;">Srlno :</label><input type="text" id="srlno" class="form-control text-end" style="width: 80px;"></div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-3">
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-success" onclick="updateTransaction()"><i class="bi bi-save"></i> Update (End)</button>
                            <button type="button" class="btn btn-danger" onclick="deleteSelectedItem()"><i class="bi bi-trash"></i> Delete Item</button>
                        </div>
                        <div>
                            <button type="button" class="btn btn-secondary" onclick="cancelModification()"><i class="bi bi-x-circle"></i> Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection

<!-- Item and Batch Selection Modal Components -->
@include('components.modals.item-selection', [
    'id' => 'godownBreakageExpiryModItemModal',
    'module' => 'godown-breakage-expiry-mod',
    'showStock' => true,
    'rateType' => 's_rate',
    'showCompany' => true,
    'showHsn' => false,
    'batchModalId' => 'godownBreakageExpiryModBatchModal',
])

@include('components.modals.batch-selection', [
    'id' => 'godownBreakageExpiryModBatchModal',
    'module' => 'godown-breakage-expiry-mod',
    'showOnlyAvailable' => true,
    'rateType' => 's_rate',
    'showCostDetails' => false,
])

@push('scripts')
<script>
let currentRowIndex = 0;
let itemsData = [];
let selectedRowIndex = null;
let loadedTransactionId = null;

document.addEventListener('DOMContentLoaded', function() {
    loadItems();
    const urlParams = new URLSearchParams(window.location.search);
    const loadId = urlParams.get('load');
    if (loadId) {
        setTimeout(() => loadTransactionData(loadId), 300);
    } else {
        // Focus Load Invoice button on page load
        setTimeout(() => {
            const btn = document.getElementById('gbem_loadInvoiceBtn');
            if (btn) btn.focus();
        }, 300);
    }
});

function updateDayName() {
    const dateInput = document.getElementById('transaction_date');
    const dayInput = document.getElementById('day_name');
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayInput.value = days[date.getDay()];
    }
}

function loadItems() {
    fetch('{{ route("admin.godown-breakage-expiry.getItems") }}')
        .then(response => response.json())
        .then(data => { itemsData = data || []; })
        .catch(error => console.error('Error loading items:', error));
}

// ============================================================================
// BRIDGE FUNCTIONS FOR REUSABLE MODAL COMPONENTS
// ============================================================================

/**
 * Bridge function called by reusable modal components after item and batch selection
 * Supports both creating new rows and updating existing rows based on targetRowIndex
 */
function onItemBatchSelectedFromModal(itemData, batchData) {
    console.log('🎯 Godown Breakage Expiry Mod: onItemBatchSelectedFromModal called', {itemData, batchData});
    
    if (!itemData || !itemData.id) {
        console.error('❌ Godown Breakage Expiry Mod: Invalid item data received');
        return;
    }
    
    const tbody = document.getElementById('itemsTableBody');
    
    // Check if we should update existing row or create new one
    const targetRowIndex = window.targetRowIndexForModal;
    const shouldCreateNewRow = (targetRowIndex === null || targetRowIndex === undefined);
    
    if (shouldCreateNewRow) {
        // CREATE NEW ROW
        const rowIndex = currentRowIndex++;
        const row = document.createElement('tr');
        row.id = `row-${rowIndex}`;
        row.dataset.rowIndex = rowIndex;
        row.dataset.itemId = itemData.id;
        row.onclick = function() { selectRow(rowIndex); };
        
        // Store item and batch data
        row.dataset.itemData = JSON.stringify({
            packing: itemData.packing || '',
            unit: itemData.unit || '1',
            mrp: itemData.mrp || 0,
            s_rate: itemData.s_rate || 0,
            p_rate: itemData.p_rate || itemData.pur_rate || 0,
            company_name: itemData.company_name || ''
        });
        
        if (batchData && batchData.id) {
            row.dataset.batchId = batchData.id;
            row.dataset.batchData = JSON.stringify({
                qty: batchData.qty || batchData.available_qty || 0,
                location: batchData.location || ''
            });
        }
        
        const cost = batchData?.pur_rate || batchData?.cost || batchData?.avg_pur_rate || itemData.p_rate || itemData.pur_rate || 0;
        const qty = 1;
        const amount = (qty * cost).toFixed(2);
        
        row.innerHTML = `
            <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][code]" value="${itemData.id || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
            <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][name]" value="${itemData.name || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
            <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][batch]" value="${batchData?.batch_no || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
            <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][expiry]" value="${batchData?.expiry_display || batchData?.expiry || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
            <td class="brex-td">
                <div class="brex-dropdown" id="brex-dropdown-${rowIndex}">
                    <input type="text" class="brex-display" id="brex-display-${rowIndex}" value="Brk" readonly onclick="toggleBrexDropdown(${rowIndex})" onfocus="selectRow(${rowIndex}); openBrexDropdown(${rowIndex})" data-custom-enter>
                    <input type="hidden" name="items[${rowIndex}][br_ex_type]" id="brex-value-${rowIndex}" value="BREAKAGE">
                    <div class="brex-list" id="brex-list-${rowIndex}">
                        <div class="brex-option selected" data-value="BREAKAGE" onclick="selectBrexOption(${rowIndex}, 'BREAKAGE', 'Brk')">Brk</div>
                        <div class="brex-option" data-value="EXPIRY" onclick="selectBrexOption(${rowIndex}, 'EXPIRY', 'Exp')">Exp</div>
                    </div>
                </div>
            </td>
            <td><input type="number" class="form-control form-control-sm" name="items[${rowIndex}][qty]" value="${qty}" onchange="calculateRowAmount(${rowIndex})" onkeydown="handleGbeModQtyKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
            <td><input type="number" class="form-control form-control-sm" name="items[${rowIndex}][cost]" value="${cost}" step="0.01" onchange="calculateRowAmount(${rowIndex})" onkeydown="handleGbeModCostKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
            <td><input type="number" class="form-control form-control-sm readonly-field" name="items[${rowIndex}][amount]" value="${amount}" step="0.01" readonly onfocus="selectRow(${rowIndex})"></td>
            <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(${rowIndex})"><i class="bi bi-x"></i></button></td>
            <input type="hidden" name="items[${rowIndex}][item_id]" value="${itemData.id || ''}">
            <input type="hidden" name="items[${rowIndex}][batch_id]" value="${batchData?.id || ''}">
            <input type="hidden" name="items[${rowIndex}][packing]" value="${itemData.packing || ''}">
            <input type="hidden" name="items[${rowIndex}][unit]" value="${itemData.unit || '1'}">
        `;
        
        tbody.appendChild(row);
        row.classList.add('row-complete');
        selectRow(rowIndex);
        calculateRowAmount(rowIndex);
        
        console.log('✅ Godown Breakage Expiry Mod: New row created successfully', rowIndex);
        
        // Focus Br/Ex field
        setTimeout(() => {
            const brexDisplay = document.getElementById(`brex-display-${rowIndex}`);
            if (brexDisplay) brexDisplay.focus();
        }, 100);
        
    } else {
        // UPDATE EXISTING ROW
        const row = document.getElementById(`row-${targetRowIndex}`);
        if (!row) {
            console.error('❌ Godown Breakage Expiry Mod: Target row not found', targetRowIndex);
            return;
        }
        
        row.dataset.itemId = itemData.id;
        row.dataset.mrp = itemData.mrp || 0;
        row.dataset.sRate = itemData.s_rate || 0;
        
        if (batchData && batchData.id) {
            row.dataset.batchId = batchData.id;
            row.dataset.clQty = batchData.qty || batchData.available_qty || 0;
        }
        
        const cost = batchData?.pur_rate || batchData?.cost || batchData?.avg_pur_rate || itemData.p_rate || itemData.pur_rate || 0;
        
        // Update row fields
        row.querySelector('input[name*="[code]"]').value = itemData.id || '';
        row.querySelector('input[name*="[name]"]').value = itemData.name || '';
        row.querySelector('input[name*="[batch]"]').value = batchData?.batch_no || '';
        row.querySelector('input[name*="[expiry]"]').value = batchData?.expiry_display || batchData?.expiry || '';
        row.querySelector('input[name*="[cost]"]').value = cost;
        row.querySelector('input[name*="[item_id]"]').value = itemData.id || '';
        row.querySelector('input[name*="[batch_id]"]').value = batchData?.id || '';
        row.querySelector('input[name*="[packing]"]').value = itemData.packing || '';
        row.querySelector('input[name*="[unit]"]').value = itemData.unit || '1';
        
        row.classList.add('row-complete');
        calculateRowAmount(targetRowIndex);
        
        console.log('✅ Godown Breakage Expiry Mod: Existing row updated successfully', targetRowIndex);
    }
    
    // Update footer
    document.getElementById('packing').value = itemData.packing || '';
    document.getElementById('unit').value = itemData.unit || '1';
    document.getElementById('p_rate').value = itemData.p_rate || itemData.pur_rate || '0';
    document.getElementById('s_rate').value = itemData.s_rate || '0';
    document.getElementById('mrp').value = itemData.mrp || '0';
    document.getElementById('cl_qty').value = batchData?.qty || batchData?.available_qty || '0';
    
    calculateTotalAmount();
    
    // Clear target row index
    window.targetRowIndexForModal = null;
    
    console.log('✅ Godown Breakage Expiry Mod: Footer updated, targetRowIndex cleared');
}

/**
 * Bridge function to open item selection modal
 * Supports targetRowIndex parameter for updating existing rows
 * @param {number|null} targetRowIndex - Row index to update, or null to create new row
 */
function showItemSelectionModal(targetRowIndex = null) {
    console.log('🎯 Godown Breakage Expiry Mod: showItemSelectionModal called', {targetRowIndex});
    
    // Store targetRowIndex for later use
    window.targetRowIndexForModal = targetRowIndex;
    
    // Check if modal component function exists
    if (typeof window.openItemModal_godownBreakageExpiryModItemModal === 'function') {
        console.log('✅ Godown Breakage Expiry Mod: Opening reusable item modal');
        window.openItemModal_godownBreakageExpiryModItemModal();
    } else {
        console.error('❌ Godown Breakage Expiry Mod: openItemModal_godownBreakageExpiryModItemModal function not found. Modal component may not be loaded.');
        alert('Error: Item selection modal not available. Please refresh the page.');
    }
}

// ============================================================================
// LEGACY FUNCTIONS (Kept as fallback, prefixed with _legacy_)
// ============================================================================

function showLoadInvoiceModal() {
    let html = `
        <div class="batch-modal-backdrop show" id="loadInvoiceBackdrop"></div>
        <div class="batch-modal show" id="loadInvoiceModal" style="max-width: 900px;">
            <div class="modal-header-custom" style="background: #fd7e14;">
                <h5 class="mb-0"><i class="bi bi-folder2-open me-2"></i>Load Invoice</h5>
                <button type="button" class="btn-close btn-close-white" onclick="closeLoadInvoiceModal()"></button>
            </div>
            <div class="modal-body-custom">
                <div class="mb-3"><input type="text" class="form-control" id="invoiceSearchInput" placeholder="Search by TRN No..." oninput="searchInvoices()"></div>
                <div class="table-responsive" style="max-height: 350px; overflow-y: auto;">
                    <table class="table table-bordered table-sm" style="font-size: 11px;">
                        <thead class="table-warning" style="position: sticky; top: 0;">
                            <tr><th>TRN No.</th><th>Date</th><th>Narration</th><th class="text-end">Amount</th><th>Action</th></tr>
                        </thead>
                        <tbody id="invoicesListBody"><tr><td colspan="5" class="text-center">Loading...</td></tr></tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer-custom"><button type="button" class="btn btn-secondary btn-sm" onclick="closeLoadInvoiceModal()">Close</button></div>
        </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    invoiceActiveIndex = -1;
    document.getElementById('invoiceSearchInput')?.focus();
    loadPastInvoices();
}

function loadPastInvoices(search = '') {
    fetch(`{{ route("admin.godown-breakage-expiry.getPastInvoices") }}?search=${encodeURIComponent(search)}`)
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('invoicesListBody');
            if (data.length === 0) { tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No invoices found</td></tr>'; return; }
            tbody.innerHTML = data.map(inv => `
                <tr class="invoice-row" onclick="selectInvoice(${inv.id})" style="cursor: pointer;">
                    <td><strong>${inv.trn_no}</strong></td>
                    <td>${inv.transaction_date ? new Date(inv.transaction_date).toLocaleDateString('en-GB') : '-'}</td>
                    <td>${inv.narration || '-'}</td>
                    <td class="text-end">₹${parseFloat(inv.total_amount || 0).toFixed(2)}</td>
                    <td class="text-center"><button type="button" class="btn btn-sm btn-success py-0 px-2" onclick="event.stopPropagation(); selectInvoice(${inv.id})"><i class="bi bi-check"></i></button></td>
                </tr>
            `).join('');
            invoiceActiveIndex = 0;
            highlightInvoiceRow();
        });
}

function searchInvoices() { loadPastInvoices(document.getElementById('invoiceSearchInput').value); }
function closeLoadInvoiceModal() { document.getElementById('loadInvoiceModal')?.remove(); document.getElementById('loadInvoiceBackdrop')?.remove(); }
function selectInvoice(id) { closeLoadInvoiceModal(); loadTransactionData(id); }

function loadTransactionData(id) {
    fetch(`{{ url('admin/godown-breakage-expiry') }}/${id}`, { headers: { 'Accept': 'application/json' } })
    .then(response => response.json())
    .then(data => { if (data && data.id) { populateForm(data); } else { alert('Transaction not found'); } })
    .catch(error => { console.error('Error:', error); alert('Error loading transaction'); });
}

function populateForm(transaction) {
    loadedTransactionId = transaction.id;
    document.getElementById('transaction_id').value = transaction.id;
    document.getElementById('transaction_date').value = transaction.transaction_date ? transaction.transaction_date.split('T')[0] : '';
    updateDayName();
    document.getElementById('trn_no').value = transaction.trn_no || '';
    document.getElementById('narration').value = transaction.narration || '';
    document.getElementById('total_amount').value = parseFloat(transaction.total_amount || 0).toFixed(2);
    
    const tbody = document.getElementById('itemsTableBody');
    tbody.innerHTML = '';
    currentRowIndex = 0;
    
    if (transaction.items && transaction.items.length > 0) {
        transaction.items.forEach((item, index) => {
            addItemRowFromData(item);
            if (index === 0) selectRow(0);
        });
    }
    calculateTotalAmount();
    // Focus date field after loading
    setTimeout(() => {
        document.getElementById('transaction_date')?.focus();
    }, 100);
}

function addItemRowFromData(item) {
    const tbody = document.getElementById('itemsTableBody');
    const rowIndex = currentRowIndex++;
    const row = document.createElement('tr');
    row.id = `row-${rowIndex}`;
    row.dataset.rowIndex = rowIndex;
    row.dataset.itemId = item.item_id || '';
    row.dataset.batchId = item.batch_id || '';
    row.dataset.mrp = item.mrp || '0';
    row.dataset.sRate = item.s_rate || '0';
    row.dataset.clQty = '0';
    row.onclick = function() { selectRow(rowIndex); };
    row.className = 'row-complete';
    
    row.innerHTML = `
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][code]" value="${item.item_code || item.item_id || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][name]" value="${item.item_name || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][batch]" value="${item.batch_no || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][expiry]" value="${item.expiry || ''}" readonly onfocus="selectRow(${rowIndex})"></td>
        <td class="brex-td">
            <div class="brex-dropdown" id="brex-dropdown-${rowIndex}">
                <input type="text" class="brex-display" id="brex-display-${rowIndex}" value="${item.br_ex_type == 'EXPIRY' ? 'Exp' : 'Brk'}" readonly onclick="toggleBrexDropdown(${rowIndex})" onfocus="selectRow(${rowIndex}); openBrexDropdown(${rowIndex})" data-custom-enter>
                <input type="hidden" name="items[${rowIndex}][br_ex_type]" id="brex-value-${rowIndex}" value="${item.br_ex_type || 'BREAKAGE'}">
                <div class="brex-list" id="brex-list-${rowIndex}">
                    <div class="brex-option ${item.br_ex_type != 'EXPIRY' ? 'selected' : ''}" data-value="BREAKAGE" onclick="selectBrexOption(${rowIndex}, 'BREAKAGE', 'Brk')">Brk</div>
                    <div class="brex-option ${item.br_ex_type == 'EXPIRY' ? 'selected' : ''}" data-value="EXPIRY" onclick="selectBrexOption(${rowIndex}, 'EXPIRY', 'Exp')">Exp</div>
                </div>
            </div>
        </td>
        <td><input type="number" class="form-control form-control-sm" name="items[${rowIndex}][qty]" value="${item.qty || 0}" onchange="calculateRowAmount(${rowIndex})" onkeydown="handleGbeModQtyKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
        <td><input type="number" class="form-control form-control-sm" name="items[${rowIndex}][cost]" value="${parseFloat(item.cost || 0).toFixed(2)}" step="0.01" onchange="calculateRowAmount(${rowIndex})" onkeydown="handleGbeModCostKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
        <td><input type="number" class="form-control form-control-sm readonly-field" name="items[${rowIndex}][amount]" value="${parseFloat(item.amount || 0).toFixed(2)}" readonly onfocus="selectRow(${rowIndex})"></td>
        <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(${rowIndex})"><i class="bi bi-x"></i></button></td>
        <input type="hidden" name="items[${rowIndex}][item_id]" value="${item.item_id || ''}">
        <input type="hidden" name="items[${rowIndex}][batch_id]" value="${item.batch_id || ''}">
        <input type="hidden" name="items[${rowIndex}][packing]" value="${item.packing || ''}">
        <input type="hidden" name="items[${rowIndex}][unit]" value="${item.unit || ''}">
    `;
    tbody.appendChild(row);
}


function addNewRow() {
    const tbody = document.getElementById('itemsTableBody');
    const rowIndex = currentRowIndex++;
    const row = document.createElement('tr');
    row.id = `row-${rowIndex}`;
    row.dataset.rowIndex = rowIndex;
    row.onclick = function() { selectRow(rowIndex); };
    
    row.innerHTML = `
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][code]" onkeydown="handleCodeKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][name]" readonly onfocus="selectRow(${rowIndex})"></td>
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][batch]" onclick="_legacy_showBatchModal(${rowIndex})" readonly style="cursor: pointer;" onfocus="selectRow(${rowIndex})"></td>
        <td><input type="text" class="form-control form-control-sm" name="items[${rowIndex}][expiry]" readonly onfocus="selectRow(${rowIndex})"></td>
        <td class="brex-td">
            <div class="brex-dropdown" id="brex-dropdown-${rowIndex}">
                <input type="text" class="brex-display" id="brex-display-${rowIndex}" value="Brk" readonly onclick="toggleBrexDropdown(${rowIndex})" onfocus="selectRow(${rowIndex}); openBrexDropdown(${rowIndex})" data-custom-enter>
                <input type="hidden" name="items[${rowIndex}][br_ex_type]" id="brex-value-${rowIndex}" value="BREAKAGE">
                <div class="brex-list" id="brex-list-${rowIndex}">
                    <div class="brex-option selected" data-value="BREAKAGE" onclick="selectBrexOption(${rowIndex}, 'BREAKAGE', 'Brk')">Brk</div>
                    <div class="brex-option" data-value="EXPIRY" onclick="selectBrexOption(${rowIndex}, 'EXPIRY', 'Exp')">Exp</div>
                </div>
            </div>
        </td>
        <td><input type="number" class="form-control form-control-sm" name="items[${rowIndex}][qty]" value="0" onchange="calculateRowAmount(${rowIndex})" onkeydown="handleGbeModQtyKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
        <td><input type="number" class="form-control form-control-sm" name="items[${rowIndex}][cost]" value="0" step="0.01" onchange="calculateRowAmount(${rowIndex})" onkeydown="handleGbeModCostKeydown(event, ${rowIndex})" onfocus="selectRow(${rowIndex})" data-custom-enter></td>
        <td><input type="number" class="form-control form-control-sm readonly-field" name="items[${rowIndex}][amount]" value="0" readonly onfocus="selectRow(${rowIndex})"></td>
        <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(${rowIndex})"><i class="bi bi-x"></i></button></td>
        <input type="hidden" name="items[${rowIndex}][item_id]" value="">
        <input type="hidden" name="items[${rowIndex}][batch_id]" value="">
        <input type="hidden" name="items[${rowIndex}][packing]" value="">
        <input type="hidden" name="items[${rowIndex}][unit]" value="">
    `;
    tbody.appendChild(row);
    selectRow(rowIndex);
    row.querySelector('input[name*="[code]"]').focus();
}

function selectRow(rowIndex) {
    document.querySelectorAll('#itemsTableBody tr').forEach(tr => tr.classList.remove('row-selected'));
    const row = document.getElementById(`row-${rowIndex}`);
    if (row) { 
        row.classList.add('row-selected'); 
        selectedRowIndex = rowIndex;
        updateFooterFromRow(row);
    }
}

function updateFooterFromRow(row) {
    if (!row) return;
    document.getElementById('packing').value = row.querySelector('input[name*="[packing]"]')?.value || '';
    document.getElementById('unit').value = row.querySelector('input[name*="[unit]"]')?.value || '';
    document.getElementById('p_rate').value = row.querySelector('input[name*="[cost]"]')?.value || '0';
    document.getElementById('s_rate').value = row.dataset.sRate || '0';
    document.getElementById('mrp').value = row.dataset.mrp || '0';
    document.getElementById('cl_qty').value = row.dataset.clQty || '0';
}

function handleCodeKeydown(event, rowIndex) {
    if (event.key === 'Enter') {
        event.preventDefault();
        const code = event.target.value.trim();
        if (code) { findItemByCode(code, rowIndex); } else { showItemSelectionModal(rowIndex); }
    }
}

function findItemByCode(code, rowIndex) {
    const item = itemsData.find(i => i.id == code || i.name.toLowerCase().includes(code.toLowerCase()));
    if (item) { selectItemForRow(item, rowIndex); } else { showItemSelectionModal(rowIndex); }
}

function _legacy_showItemSelectionModal(targetRowIndex = null) {
    const rowIndex = targetRowIndex !== null ? targetRowIndex : selectedRowIndex;
    let html = `
        <div class="batch-modal-backdrop show" id="itemModalBackdrop"></div>
        <div class="batch-modal show" id="itemModal" style="max-width: 900px;">
            <div class="modal-header-custom"><h5 class="mb-0"><i class="bi bi-search me-2"></i>Select Item</h5><button type="button" class="btn-close btn-close-white" onclick="_legacy_closeItemModal()"></button></div>
            <div class="modal-body-custom">
                <div class="mb-3"><input type="text" class="form-control" id="itemSearchInput" placeholder="Search..." onkeyup="_legacy_filterItems()"></div>
                <div class="table-responsive" style="max-height: 350px; overflow-y: auto;">
                    <table class="table table-bordered table-sm" style="font-size: 11px;">
                        <thead class="table-info" style="position: sticky; top: 0;"><tr><th>Code</th><th>Item Name</th><th>Packing</th><th>Company</th><th class="text-end">MRP</th></tr></thead>
                        <tbody id="itemsListBody"></tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer-custom"><button type="button" class="btn btn-secondary btn-sm" onclick="_legacy_closeItemModal()">Close</button></div>
        </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    document.body.dataset.targetRowIndex = rowIndex;
    document.getElementById('itemSearchInput').focus();
    _legacy_renderItemsList();
}

function _legacy_renderItemsList(filter = '') {
    const tbody = document.getElementById('itemsListBody');
    const filtered = filter ? itemsData.filter(item => item.name.toLowerCase().includes(filter.toLowerCase()) || item.id.toString().includes(filter)) : itemsData;
    tbody.innerHTML = filtered.slice(0, 100).map(item => `
        <tr class="item-row" onclick="_legacy_selectItem(${item.id})" style="cursor: pointer;">
            <td>${item.id}</td><td>${item.name}</td><td>${item.packing || '-'}</td><td>${item.company_name || '-'}</td><td class="text-end">${parseFloat(item.mrp || 0).toFixed(2)}</td>
        </tr>
    `).join('');
}

function _legacy_filterItems() { _legacy_renderItemsList(document.getElementById('itemSearchInput').value); }

function _legacy_selectItem(itemId) {
    const item = itemsData.find(i => i.id === itemId);
    if (item) { _legacy_selectItemForRow(item, parseInt(document.body.dataset.targetRowIndex)); _legacy_closeItemModal(); }
}

function _legacy_selectItemForRow(item, rowIndex) {
    const row = document.getElementById(`row-${rowIndex}`);
    if (!row) return;
    row.querySelector('input[name*="[code]"]').value = item.id;
    row.querySelector('input[name*="[name]"]').value = item.name;
    row.querySelector('input[name*="[item_id]"]').value = item.id;
    row.querySelector('input[name*="[packing]"]').value = item.packing || '';
    row.querySelector('input[name*="[unit]"]').value = item.unit || '';
    row.querySelector('input[name*="[cost]"]').value = item.p_rate || 0;
    row.dataset.itemId = item.id;
    row.dataset.mrp = item.mrp || 0;
    row.dataset.sRate = item.s_rate || 0;
    updateFooterFromRow(row);
    _legacy_showBatchModal(rowIndex);
}

function _legacy_closeItemModal() { document.getElementById('itemModal')?.remove(); document.getElementById('itemModalBackdrop')?.remove(); }

function _legacy_showBatchModal(rowIndex) {
    const row = document.getElementById(`row-${rowIndex}`);
    if (!row || !row.dataset.itemId) { alert('Please select an item first'); return; }
    
    let html = `
        <div class="batch-modal-backdrop show" id="batchModalBackdrop"></div>
        <div class="batch-modal show" id="batchModal">
            <div class="modal-header-custom" style="background: #ffc107; color: #000;"><h5 class="mb-0"><i class="bi bi-box me-2"></i>Select Batch</h5><button type="button" class="btn-close" onclick="_legacy_closeBatchModal()"></button></div>
            <div class="modal-body-custom"><div class="text-center py-3"><div class="spinner-border text-warning"></div><div class="mt-2">Loading...</div></div></div>
            <div class="modal-footer-custom"><button type="button" class="btn btn-secondary btn-sm" onclick="_legacy_closeBatchModal()">Close</button></div>
        </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    document.body.dataset.batchRowIndex = rowIndex;
    
    fetch(`{{ url('admin/api/item-batches') }}/${row.dataset.itemId}`)
        .then(response => response.json())
        .then(data => {
            const modalBody = document.querySelector('#batchModal .modal-body-custom');
            // Handle response format: { success: true, batches: [...] }
            const batches = data.batches || data || [];
            if (!batches || batches.length === 0) { modalBody.innerHTML = '<div class="text-center text-muted py-3">No batches available</div>'; return; }
            modalBody.innerHTML = `<div class="table-responsive"><table class="table table-bordered table-sm" style="font-size: 11px;">
                <thead class="table-warning"><tr><th>Batch No</th><th>Expiry</th><th class="text-end">Qty</th><th class="text-end">MRP</th><th class="text-end">P.Rate</th><th class="text-end">S.Rate</th></tr></thead>
                <tbody>${batches.map(b => `<tr class="batch-row" onclick="_legacy_selectBatch(${b.id}, '${(b.batch_no || '').replace(/'/g, "\\'")}', '${(b.expiry_display || '').replace(/'/g, "\\'")}', ${b.qty || 0}, ${b.pur_rate || b.cost || 0}, ${b.mrp || 0}, ${b.s_rate || 0})" style="cursor: pointer;"><td>${b.batch_no || '-'}</td><td>${b.expiry_display || '-'}</td><td class="text-end">${b.qty || 0}</td><td class="text-end">${parseFloat(b.mrp || 0).toFixed(2)}</td><td class="text-end">${parseFloat(b.pur_rate || b.cost || 0).toFixed(2)}</td><td class="text-end">${parseFloat(b.s_rate || 0).toFixed(2)}</td></tr>`).join('')}</tbody>
            </table></div>`;
        })
        .catch(error => {
            console.error('Error loading batches:', error);
            document.querySelector('#batchModal .modal-body-custom').innerHTML = '<div class="text-center text-danger py-3">Error loading batches</div>';
        });
}

function _legacy_selectBatch(batchId, batchNo, expiry, qty, pRate, mrp, sRate) {
    const row = document.getElementById(`row-${document.body.dataset.batchRowIndex}`);
    if (!row) return;
    row.querySelector('input[name*="[batch]"]').value = batchNo;
    row.querySelector('input[name*="[expiry]"]').value = expiry;
    row.querySelector('input[name*="[batch_id]"]').value = batchId;
    row.querySelector('input[name*="[cost]"]').value = pRate || 0;
    row.dataset.batchId = batchId;
    row.dataset.clQty = qty || 0;
    row.dataset.mrp = mrp || 0;
    row.dataset.sRate = sRate || 0;
    row.classList.add('row-complete');
    _legacy_closeBatchModal();
    updateFooterFromRow(row);
    row.querySelector('input[name*="[qty]"]').focus();
}

function _legacy_closeBatchModal() { document.getElementById('batchModal')?.remove(); document.getElementById('batchModalBackdrop')?.remove(); }

function calculateRowAmount(rowIndex) {
    const row = document.getElementById(`row-${rowIndex}`);
    if (!row) return;
    const qty = parseFloat(row.querySelector('input[name*="[qty]"]').value) || 0;
    const cost = parseFloat(row.querySelector('input[name*="[cost]"]').value) || 0;
    row.querySelector('input[name*="[amount]"]').value = (qty * cost).toFixed(2);
    calculateTotalAmount();
}

function calculateTotalAmount() {
    let total = 0;
    document.querySelectorAll('#itemsTableBody tr').forEach(row => { total += parseFloat(row.querySelector('input[name*="[amount]"]')?.value) || 0; });
    document.getElementById('total_amount').value = total.toFixed(2);
}

function removeRow(rowIndex) { document.getElementById(`row-${rowIndex}`)?.remove(); calculateTotalAmount(); }
function deleteSelectedItem() { if (selectedRowIndex !== null) { removeRow(selectedRowIndex); selectedRowIndex = null; } }

let isSubmitting = false;

function updateTransaction() {
    if (!loadedTransactionId) { alert('Please load an invoice first'); return; }
    
    // Prevent double submission
    if (isSubmitting) { return; }
    isSubmitting = true;
    
    // Disable button and show loading
    const updateBtn = document.querySelector('button[onclick="updateTransaction()"]');
    const originalBtnHtml = updateBtn.innerHTML;
    updateBtn.disabled = true;
    updateBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Updating...';
    
    const formData = new FormData(document.getElementById('gbeForm'));
    let totalQty = 0;
    document.querySelectorAll('#itemsTableBody tr').forEach(row => { totalQty += parseFloat(row.querySelector('input[name*="[qty]"]')?.value) || 0; });
    formData.append('total_qty', totalQty);
    formData.set('_method', 'PUT');
    
    // 🔥 Mark as saving to prevent exit confirmation dialog
    if (typeof window.markAsSaving === 'function') {
        window.markAsSaving();
    }
    
    fetch(`{{ url('admin/godown-breakage-expiry') }}/${loadedTransactionId}`, {
        method: 'POST', body: formData, headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) { alert(data.message); window.location.href = '{{ route("admin.godown-breakage-expiry.index") }}'; }
        else { 
            alert(data.message || 'Error updating');
            isSubmitting = false;
            updateBtn.disabled = false;
            updateBtn.innerHTML = originalBtnHtml;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating');
        isSubmitting = false;
        updateBtn.disabled = false;
        updateBtn.innerHTML = originalBtnHtml;
    });
}

function cancelModification() { if (confirm('Cancel modification?')) { window.location.href = '{{ route("admin.godown-breakage-expiry.index") }}'; } }

// ============================================================================
// CUSTOM BR/EX DROPDOWN FUNCTIONS
// ============================================================================

function openBrexDropdown(rowIndex) {
    document.querySelectorAll('.brex-list.show').forEach(l => {
        if (l.id !== `brex-list-${rowIndex}`) l.classList.remove('show');
    });
    const list = document.getElementById(`brex-list-${rowIndex}`);
    if (list && !list.classList.contains('show')) {
        list.classList.add('show');
        const container = document.getElementById('itemsTableContainer');
        if (container) container.classList.add('brex-open');
        const currentVal = document.getElementById(`brex-value-${rowIndex}`).value;
        list.querySelectorAll('.brex-option').forEach(opt => {
            opt.classList.remove('active');
            if (opt.dataset.value === currentVal) opt.classList.add('active');
        });
    }
}

function toggleBrexDropdown(rowIndex) {
    const list = document.getElementById(`brex-list-${rowIndex}`);
    const isOpen = list.classList.contains('show');
    closeAllBrexDropdowns();
    if (!isOpen) {
        list.classList.add('show');
        const container = document.getElementById('itemsTableContainer');
        if (container) container.classList.add('brex-open');
        const currentVal = document.getElementById(`brex-value-${rowIndex}`).value;
        list.querySelectorAll('.brex-option').forEach(opt => {
            opt.classList.remove('active');
            if (opt.dataset.value === currentVal) opt.classList.add('active');
        });
    }
}

function selectBrexOption(rowIndex, value, displayText) {
    document.getElementById(`brex-display-${rowIndex}`).value = displayText;
    document.getElementById(`brex-value-${rowIndex}`).value = value;
    const list = document.getElementById(`brex-list-${rowIndex}`);
    list.querySelectorAll('.brex-option').forEach(opt => {
        opt.classList.remove('selected', 'active');
        if (opt.dataset.value === value) opt.classList.add('selected');
    });
    closeAllBrexDropdowns();
    const row = document.getElementById(`row-${rowIndex}`);
    if (row) { const qtyInput = row.querySelector('input[name*="[qty]"]'); if (qtyInput) { qtyInput.focus(); qtyInput.select(); } }
}

function selectBrexOptionQuiet(rowIndex, value, displayText) {
    document.getElementById(`brex-display-${rowIndex}`).value = displayText;
    document.getElementById(`brex-value-${rowIndex}`).value = value;
    const list = document.getElementById(`brex-list-${rowIndex}`);
    list.querySelectorAll('.brex-option').forEach(opt => {
        opt.classList.remove('selected', 'active');
        if (opt.dataset.value === value) opt.classList.add('selected', 'active');
    });
}

function closeAllBrexDropdowns() {
    document.querySelectorAll('.brex-list.show').forEach(l => l.classList.remove('show'));
    const container = document.getElementById('itemsTableContainer');
    if (container) container.classList.remove('brex-open');
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('.brex-dropdown')) closeAllBrexDropdowns();
});

// ============================================================================
// QTY & COST KEYDOWN HANDLERS
// ============================================================================

function handleGbeModQtyKeydown(event, rowIndex) {
    if (event.key !== 'Enter' && event.key !== 'Tab') return;

    const qtyInput = event.target;
    const qty = parseFloat(qtyInput?.value) || 0;
    if (qty <= 0) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        qtyInput?.focus();
        qtyInput?.select();
        return;
    }

    // Keep native Tab behavior when qty is valid.
    if (event.key === 'Tab') return;

    if (event.key === 'Enter') {
        if (event.ctrlKey) return; // let global handler handle Ctrl+Enter
        event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
        calculateRowAmount(rowIndex);
        if (event.shiftKey) {
            // Shift+Enter → back to Br/Ex
            const brex = document.getElementById(`brex-display-${rowIndex}`);
            if (brex) brex.focus();
            return;
        }
        // Enter → Cost
        const row = document.getElementById(`row-${rowIndex}`);
        if (row) { const cost = row.querySelector('input[name*="[cost]"]'); if (cost) { cost.focus(); cost.select(); } }
    }
}

function handleGbeModCostKeydown(event, rowIndex) {
    if (event.key === 'Enter') {
        if (event.ctrlKey) return; // let global handler handle Ctrl+Enter
        event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
        calculateRowAmount(rowIndex);
        if (event.shiftKey) {
            // Shift+Enter → back to Qty
            const row = document.getElementById(`row-${rowIndex}`);
            if (row) { const qty = row.querySelector('input[name*="[qty]"]'); if (qty) { qty.focus(); qty.select(); } }
            return;
        }
        // Enter → next row's Br/Ex or Add Items
        const currentRow = document.getElementById(`row-${rowIndex}`);
        const nextRow = currentRow ? currentRow.nextElementSibling : null;
        if (nextRow && nextRow.id && nextRow.id.startsWith('row-')) {
            const nextIdx = parseInt(nextRow.id.replace('row-', ''));
            selectRow(nextIdx);
            const brex = document.getElementById(`brex-display-${nextIdx}`);
            if (brex) brex.focus();
        } else {
            showItemSelectionModal();
        }
    }
}

// ============================================================================
// INVOICE MODAL KEYBOARD NAV
// ============================================================================
let invoiceActiveIndex = -1;
function highlightInvoiceRow() {
    const rows = document.querySelectorAll('#invoicesListBody tr.invoice-row');
    rows.forEach(r => { r.style.backgroundColor = ''; r.style.outline = ''; });
    if (invoiceActiveIndex < 0) invoiceActiveIndex = 0;
    if (invoiceActiveIndex >= rows.length) invoiceActiveIndex = rows.length - 1;
    if (rows[invoiceActiveIndex]) {
        rows[invoiceActiveIndex].style.backgroundColor = '#fff3cd';
        rows[invoiceActiveIndex].style.outline = '2px solid #ffc107';
        rows[invoiceActiveIndex].scrollIntoView({ block: 'nearest' });
    }
}

// ============================================================================
// GLOBAL KEYBOARD NAVIGATION
// ============================================================================
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === 'Tab') {
        const activeQty = document.activeElement;
        if (activeQty && activeQty.name && activeQty.name.includes('[qty]')) {
            const hasModalOpenForQty = document.getElementById('loadInvoiceModal') ||
                document.querySelector('#godownBreakageExpiryModItemModal.show') ||
                document.querySelector('#godownBreakageExpiryModBatchModal.show') ||
                document.getElementById('itemModal') ||
                document.getElementById('batchModal');

            if (!hasModalOpenForQty) {
                const qtyVal = parseFloat(activeQty.value);
                if (!(activeQty.value || '').trim() || !Number.isFinite(qtyVal) || qtyVal <= 0) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    activeQty.focus();
                    activeQty.select();
                    return false;
                }
            }
        }
    }

    // Invoice modal handler
    const invoiceModal = document.getElementById('loadInvoiceModal');
    if (invoiceModal) {
        if (e.key === 'ArrowDown') { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); invoiceActiveIndex++; highlightInvoiceRow(); return false; }
        if (e.key === 'ArrowUp') { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); invoiceActiveIndex--; highlightInvoiceRow(); return false; }
        if (e.key === 'Enter') {
            e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
            const rows = document.querySelectorAll('#invoicesListBody tr.invoice-row');
            if (invoiceActiveIndex >= 0 && rows[invoiceActiveIndex]) {
                const btn = rows[invoiceActiveIndex].querySelector('button');
                if (btn) btn.click();
                return false;
            }
            if (document.activeElement && document.activeElement.id === 'invoiceSearchInput') {
                invoiceActiveIndex = 0; highlightInvoiceRow(); document.getElementById('invoiceSearchInput')?.blur();
            }
            return false;
        }
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); closeLoadInvoiceModal(); return false; }
        // Block ALL other keys from leaking out of modal
        e.stopPropagation(); e.stopImmediatePropagation();
        return;
    }

    // Br/Ex dropdown keyboard handler
    const activeEl = document.activeElement;
    if (activeEl && activeEl.classList.contains('brex-display')) {
        const idParts = activeEl.id.split('-');
        const rowIndex = parseInt(idParts[idParts.length - 1]);
        if (isNaN(rowIndex)) return;
        const list = document.getElementById(`brex-list-${rowIndex}`);

        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault(); e.stopPropagation();
            const currentVal = document.getElementById(`brex-value-${rowIndex}`).value;
            if (currentVal === 'BREAKAGE') { selectBrexOptionQuiet(rowIndex, 'EXPIRY', 'Exp'); }
            else { selectBrexOptionQuiet(rowIndex, 'BREAKAGE', 'Brk'); }
            return;
        }
        if (e.key === 'b' || e.key === 'B') { e.preventDefault(); selectBrexOptionQuiet(rowIndex, 'BREAKAGE', 'Brk'); return; }
        if (e.key === 'e' || e.key === 'E') { e.preventDefault(); selectBrexOptionQuiet(rowIndex, 'EXPIRY', 'Exp'); return; }
        if (e.key === 'Enter') {
            if (e.ctrlKey) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); closeAllBrexDropdowns(); document.getElementById('srlno')?.focus(); document.getElementById('srlno')?.select(); return; }
            e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
            if (e.shiftKey) {
                closeAllBrexDropdowns();
                const currentRow = document.getElementById(`row-${rowIndex}`);
                const prevRow = currentRow ? currentRow.previousElementSibling : null;
                if (prevRow && prevRow.id && prevRow.id.startsWith('row-')) {
                    const prevIdx = parseInt(prevRow.id.replace('row-', ''));
                    selectRow(prevIdx);
                    const prevCost = prevRow.querySelector('input[name*="[cost]"]');
                    if (prevCost) { prevCost.focus(); prevCost.select(); }
                } else { document.getElementById('narration')?.focus(); }
                return;
            }
            closeAllBrexDropdowns();
            const row = document.getElementById(`row-${rowIndex}`);
            if (row) { const qtyInput = row.querySelector('input[name*="[qty]"]'); if (qtyInput) { qtyInput.focus(); qtyInput.select(); } }
            return;
        }
        if (e.key === 'Escape') { e.preventDefault(); closeAllBrexDropdowns(); return; }
    }

    if (e.key === 'Enter') {
        if (!activeEl) return;
        const hasModalOpen = document.querySelector('#godownBreakageExpiryModItemModal.show') || document.querySelector('#godownBreakageExpiryModBatchModal.show');
        if (hasModalOpen) return;

        // Ctrl+Enter → Srlno
        if (e.ctrlKey && !e.shiftKey) {
            e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); document.getElementById('srlno')?.focus(); document.getElementById('srlno')?.select(); return false;
        }
        // Shift+Enter backward
        if (e.shiftKey && !e.ctrlKey) {
            const backMap = { 'narration': 'transaction_date' };
            if (backMap[activeEl.id]) { e.preventDefault(); document.getElementById(backMap[activeEl.id])?.focus(); return false; }
            return;
        }
        // Date → Narration
        if (activeEl.id === 'transaction_date') { e.preventDefault(); document.getElementById('narration')?.focus(); return false; }
        // Narration → Add Items
        if (activeEl.id === 'narration') {
            e.preventDefault();
            const firstRow = document.querySelector('#itemsTableBody tr');
            if (firstRow) {
                const brex = document.getElementById(`brex-display-${firstRow.id.replace('row-', '')}`);
                if (brex) { selectRow(parseInt(firstRow.id.replace('row-', ''))); brex.focus(); return false; }
            }
            showItemSelectionModal(); return false;
        }
    }

    // Ctrl+S save
    if (e.key === 's' && e.ctrlKey && !e.shiftKey && !e.altKey) { e.preventDefault(); updateTransaction(); return false; }
}, true);
</script>

<script>
// ============================================================
// AUTO-SAVE  —  godown_breakage_expiry_modification_autosave_v1
// ============================================================
(function(){
'use strict';
const KEY = 'godown_breakage_expiry_modification_autosave_v1';
let _t = null;

function _val(id){ const el=document.getElementById(id); return el?el.value:''; }
function _set(id,v){ const el=document.getElementById(id); if(el) el.value=v; }
function _esc(v){ if(v===undefined||v===null)return''; return String(v).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }


function _buildBrexTd(ri, brexType){
    const isExp = brexType==='EXPIRY';
    const dispTxt = isExp?'Exp':'Brk';
    return '<td class="brex-td">'+
        '<div class="brex-dropdown" id="brex-dropdown-'+ri+'">'+
        '<input type="text" class="brex-display" id="brex-display-'+ri+'" value="'+dispTxt+'" readonly '+
        'onclick="toggleBrexDropdown('+ri+')" onfocus="selectRow('+ri+'); openBrexDropdown('+ri+')" data-custom-enter>'+
        '<input type="hidden" name="items['+ri+'][br_ex_type]" id="brex-value-'+ri+'" value="'+brexType+'">'+
        '<div class="brex-list" id="brex-list-'+ri+'">'+
        '<div class="brex-option'+(isExp?'':' selected')+'" data-value="BREAKAGE" onclick="selectBrexOption('+ri+',\'BREAKAGE\',\'Brk\')">Brk</div>'+
        '<div class="brex-option'+(isExp?' selected':'')+'" data-value="EXPIRY" onclick="selectBrexOption('+ri+',\'EXPIRY\',\'Exp\')">Exp</div>'+
        '</div></div></td>';
}


function save(){
    const rows=[];
    document.querySelectorAll('#itemsTableBody tr').forEach(function(tr){
        const ri=tr.dataset.rowIndex;
        if(ri===undefined||ri===null||ri==='') return;
        const g=function(n){ const el=tr.querySelector('[name="items['+ri+']['+n+']"]'); return el?el.value:''; };
        if(!g('code')&&!g('name')) return;
        rows.push({
            ri:ri,
            itemId:tr.dataset.itemId||'', itemData:tr.dataset.itemData||'{}',
            batchId:tr.dataset.batchId||'', batchData:tr.dataset.batchData||'{}',
            code:g('code'), name:g('name'), batch:g('batch'), expiry:g('expiry'),
            br_ex_type:g('br_ex_type')||'BREAKAGE',
            qty:g('qty'), cost:g('cost'), amount:g('amount'),
            item_id:g('item_id'), batch_id:g('batch_id'), packing:g('packing'), unit:g('unit'),
        });
    });

    const state={
        savedAt:new Date().toISOString(),
        transaction_id:_val('transaction_id'),
        transaction_date:_val('transaction_date'),
        trn_no:_val('trn_no'),
        narration:_val('narration'),
        srlno:_val('srlno'),
        rows:rows,
    };
    if(!state.transaction_id && !rows.length) return;
    try{ localStorage.setItem(KEY,JSON.stringify(state)); }catch(e){}
    _badge();
}
function _sched(){ clearTimeout(_t); _t=setTimeout(save,700); }

function restore(){
    let state; try{ const r=localStorage.getItem(KEY); if(!r)return; state=JSON.parse(r); }catch(e){return;}
    if(!state||!state.transaction_id) return;
    _banner(state.savedAt, function keep(){
        _set('transaction_id',state.transaction_id||'');
        _set('trn_no',state.trn_no||'');
        if(state.transaction_date) _set('transaction_date',state.transaction_date);
        if(typeof updateDayName==='function') updateDayName();
        _set('narration',state.narration||'');
        _set('srlno',state.srlno||'');

        const tbody=document.getElementById('itemsTableBody');
        if(tbody) tbody.innerHTML='';
        if(typeof currentRowIndex!=='undefined') window.currentRowIndex=0;

        (state.rows||[]).forEach(function(saved){
            const ri=saved.ri;
            if(typeof currentRowIndex!=='undefined'&&parseInt(ri)>=currentRowIndex) window.currentRowIndex=parseInt(ri)+1;
            const tr=document.createElement('tr');
            tr.id='row-'+ri;
            tr.dataset.rowIndex=ri;
            tr.dataset.itemId=saved.itemId||''; tr.dataset.itemData=saved.itemData||'{}';
            tr.dataset.batchId=saved.batchId||''; tr.dataset.batchData=saved.batchData||'{}';
            tr.onclick=function(){ if(typeof selectRow==='function') selectRow(parseInt(ri)); };
            tr.innerHTML=
                '<td><input type="text" class="form-control form-control-sm" name="items['+ri+'][code]" value="'+_esc(saved.code)+'" readonly onfocus="selectRow('+ri+')"></td>'+
                '<td><input type="text" class="form-control form-control-sm" name="items['+ri+'][name]" value="'+_esc(saved.name)+'" readonly onfocus="selectRow('+ri+')"></td>'+
                '<td><input type="text" class="form-control form-control-sm" name="items['+ri+'][batch]" value="'+_esc(saved.batch)+'" readonly onfocus="selectRow('+ri+')"></td>'+
                '<td><input type="text" class="form-control form-control-sm" name="items['+ri+'][expiry]" value="'+_esc(saved.expiry)+'" readonly onfocus="selectRow('+ri+')"></td>'+
                _buildBrexTd(ri, saved.br_ex_type||'BREAKAGE')+
                '<td><input type="number" class="form-control form-control-sm" name="items['+ri+'][qty]" value="'+_esc(saved.qty||1)+'" onchange="calculateRowAmount('+ri+')" onkeydown="handleGbeModQtyKeydown(event,'+ri+')" onfocus="selectRow('+ri+')" data-custom-enter></td>'+
                '<td><input type="number" class="form-control form-control-sm" name="items['+ri+'][cost]" value="'+parseFloat(saved.cost||0).toFixed(2)+'" step="0.01" onchange="calculateRowAmount('+ri+')" onkeydown="handleGbeModCostKeydown(event,'+ri+')" onfocus="selectRow('+ri+')" data-custom-enter></td>'+
                '<td><input type="number" class="form-control form-control-sm readonly-field" name="items['+ri+'][amount]" value="'+_esc(saved.amount||'')+'" step="0.01" readonly onfocus="selectRow('+ri+')"></td>'+
                '<td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow('+ri+')"><i class="bi bi-x"></i></button></td>'+
                '<input type="hidden" name="items['+ri+'][item_id]" value="'+_esc(saved.item_id)+'">'+
                '<input type="hidden" name="items['+ri+'][batch_id]" value="'+_esc(saved.batch_id)+'">'+
                '<input type="hidden" name="items['+ri+'][packing]" value="'+_esc(saved.packing)+'">'+
                '<input type="hidden" name="items['+ri+'][unit]" value="'+_esc(saved.unit)+'">';
            if(tbody){ tbody.appendChild(tr); tr.classList.add('row-complete'); }
        });

        if(typeof calculateTotalAmount==='function') calculateTotalAmount();
        else if(typeof calculateTotals==='function') calculateTotals();

        const ub=document.getElementById('updateBtn'); if(ub) ub.disabled=false;
    }, function discard(){ clearAutoSave(); });
}

window.clearAutoSave=function(){ try{ localStorage.removeItem(KEY); }catch(e){} };

function _badge(){
    let b=document.getElementById('_asBadge');
    if(!b){ b=document.createElement('div'); b.id='_asBadge';
      b.style.cssText='position:fixed;bottom:18px;right:18px;background:#198754;color:#fff;padding:5px 12px;border-radius:20px;font-size:11px;z-index:9999;opacity:0;transition:opacity 0.3s;pointer-events:none;';
      document.body.appendChild(b); }
    b.textContent='\u2713 Draft saved'; b.style.opacity='1';
    setTimeout(function(){ b.style.opacity='0'; },2200);
}
function _banner(savedAt,onKeep,onDiscard){
    const old=document.getElementById('_asBanner'); if(old) old.remove();
    const t=savedAt?new Date(savedAt).toLocaleTimeString():'';
    const d=document.createElement('div'); d.id='_asBanner';
    d.style.cssText='position:fixed;top:10px;left:calc(240px + 50%);transform:translateX(-50%);background:#fff3cd;border:1px solid #ffc107;padding:8px 16px;border-radius:6px;z-index:9999;display:flex;align-items:center;gap:10px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,0.15);';
    d.innerHTML='<span>\uD83D\uDCCB Unsaved draft restored'+(t?' ('+t+')':'')+' </span>'+
        '<button id="_asKeep" style="background:#198754;color:#fff;border:none;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:11px;">Keep</button>'+
        '<button id="_asDiscard" style="background:#dc3545;color:#fff;border:none;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:11px;">Discard</button>';
    document.body.appendChild(d);
    let done=false;
    function dismiss(){ if(done)return; done=true; d.remove(); }
    document.getElementById('_asKeep').onclick=function(){ dismiss(); if(onKeep) onKeep(); };
    document.getElementById('_asDiscard').onclick=function(){ dismiss(); if(onDiscard) onDiscard(); };
    setTimeout(function(){ if(!done){ dismiss(); if(onKeep) onKeep(); } },12000);
}

document.addEventListener('DOMContentLoaded',function(){
    setTimeout(function(){
        const _origMark=(typeof window.markAsSaving==='function')?window.markAsSaving:null;
        window.markAsSaving=function(){ clearAutoSave(); if(_origMark) _origMark.apply(this,arguments); };
    },800);
    setTimeout(restore,900);
    const form=document.getElementById('gbeForm');
    if(form){ form.addEventListener('input',_sched); form.addEventListener('change',_sched); }
    const tbody=document.getElementById('itemsTableBody');
    if(tbody) new MutationObserver(_sched).observe(tbody,{childList:true,subtree:true});
});
})();
</script>

@endpush