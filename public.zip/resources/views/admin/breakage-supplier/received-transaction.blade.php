@extends('layouts.admin')

@section('title', 'Breakage/Expiry to Supplier - Received Transaction')

@section('content')
<!-- Content will be added here -->
@endsection
