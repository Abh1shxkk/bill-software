@extends('layouts.admin')

@section('title', 'Breakage/Expiry to Supplier - Issued Modification')

@section('content')
<!-- Content will be added here -->
@endsection
