@extends('layouts.admin')

@section('title', 'Breakage/Expiry to Supplier - Unused Dump Modification')

@section('content')
<!-- Content will be added here -->
@endsection
